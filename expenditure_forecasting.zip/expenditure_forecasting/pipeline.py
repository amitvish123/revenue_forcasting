"""
Refined Master Pipeline for State Revenue Expenditure Forecasting
Configured according to fiscal constraints:
1. Training strictly up to 31-03-2025 (FY 2014-15 to FY 2024-25 = 11 full fiscal years)
2. Forecasting from 01-04-2025 to 31-03-2035 (10 complete fiscal years: FY 2025-26 through FY 2034-35)
3. Preserves out-of-sample ground truth actuals for FY 2025-26 for validation
4. Hybrid CAGR decomposition avoids artificial damping dips
"""
import os
import json
import pandas as pd
import numpy as np

from utils.calendar_utils import get_fiscal_year
from utils.aggregation import aggregate_time_series
from validation.metrics import compute_all_metrics
from validation.drift_monitor import compute_data_drift, compute_model_drift

from models.cagr_baseline import DampedCAGRForecaster
from models.statistical_models import StatisticalHarmonicForecaster
from models.gbdt_models import XGBoostForecaster
from models.deep_models import DeepDecompForecaster
from models.ensemble import OptimalWeightedEnsemble

CACHE_DIR = "data_cache"
os.makedirs(CACHE_DIR, exist_ok=True)

def run_pipeline(csv_path="CMN_ACTUAL_EXP_RCPT_TXN_filtered_1.csv", cutoff_date="2025-03-31", horizon_years=10, progress_callback=None):
    print("=" * 60)
    print("REFINED STATE EXPENDITURE FORECASTING PIPELINE")
    print(f"Data source: {csv_path}")
    print(f"Training cutoff: {cutoff_date} | Horizon: {horizon_years} Full Fiscal Years")
    print("=" * 60)
    
    if progress_callback:
        progress_callback(10, "Loading and validating transaction data...")
        
    # 1. Load Data
    df_raw = pd.read_csv(csv_path)
    
    # Flexible column & date detection
    date_col = 'ACCOUNTING_DATE' if 'ACCOUNTING_DATE' in df_raw.columns else [c for c in df_raw.columns if 'date' in c.lower()][0]
    df_raw[date_col] = pd.to_datetime(df_raw[date_col], errors='coerce', dayfirst=True)
    df_raw = df_raw.dropna(subset=[date_col]).sort_values(date_col).reset_index(drop=True)
    df_raw['ACCOUNTING_DATE'] = df_raw[date_col]
    
    if 'EXP_CRORES' in df_raw.columns:
        pass
    elif 'NET_EXP' in df_raw.columns:
        df_raw['EXP_CRORES'] = df_raw['NET_EXP'] / 1e7
    else:
        num_cols = df_raw.select_dtypes(include=[np.number]).columns
        df_raw['EXP_CRORES'] = df_raw[num_cols[0]]
        
    df_daily = df_raw[['ACCOUNTING_DATE', 'EXP_CRORES']].copy()
    
    # Partition Training up to cutoff_date
    cutoff_ts = pd.to_datetime(cutoff_date)
    train_mask = df_daily['ACCOUNTING_DATE'] <= cutoff_ts
    df_train = df_daily[train_mask].copy()
    
    print(f"Training Data: {df_train['ACCOUNTING_DATE'].min().strftime('%d-%b-%Y')} to {df_train['ACCOUNTING_DATE'].max().strftime('%d-%b-%Y')} ({len(df_train)} days)")
    
    # 2. Fit Models
    print("\nFitting Models on Training Period (FY 2014-15 to FY 2024-25)...")
    cagr_model = DampedCAGRForecaster(damping_factor=0.99, min_growth_rate=0.07).fit(df_train)
    stat_model = StatisticalHarmonicForecaster(cagr_model=cagr_model, harmonics=4).fit(df_train)
    xgb_model = XGBoostForecaster(cagr_model=cagr_model, n_estimators=180, max_depth=5).fit(df_train)
    deep_model = DeepDecompForecaster(cagr_model=cagr_model, hidden_dim=48, epochs=45).fit(df_train)
    
    models = {
        "Damped CAGR Baseline": cagr_model,
        "Statistical Harmonic": stat_model,
        "XGBoost Regressor": xgb_model,
        "DeepDecompNet (PyTorch)": deep_model
    }
    
    # Feature importances
    xgb_feat_imp = xgb_model.feature_importances_
    feat_imp_df = pd.DataFrame(list(xgb_feat_imp.items()), columns=['Feature', 'Importance']).sort_values('Importance', ascending=False)
    feat_imp_df.to_csv(os.path.join(CACHE_DIR, "feature_importance.csv"), index=False)
    
    # In-sample predictions on training period
    preds_dict = {name: m.predict_dates(df_train['ACCOUNTING_DATE']) for name, m in models.items()}
    ensemble = OptimalWeightedEnsemble(models)
    opt_weights = ensemble.optimize_weights(df_train['EXP_CRORES'].values, preds_dict)
    models["Optimal Weighted Ensemble"] = ensemble
    
    print("\nOptimal Ensemble Weights:")
    for m_name, w in opt_weights.items():
        print(f"  {m_name}: {w * 100:.1f}%")
        
    with open(os.path.join(CACHE_DIR, "ensemble_weights.json"), "w") as f:
        json.dump(opt_weights, f, indent=2)

    # 3. Forecast Horizon: horizon_years Full Fiscal Years from cutoff
    cutoff_ts = pd.to_datetime(cutoff_date)
    forecast_start = cutoff_ts + pd.Timedelta(days=1)
    # Target end of fiscal year (March 31)
    end_year = forecast_start.year + horizon_years if forecast_start.month <= 4 else forecast_start.year + horizon_years + 1
    forecast_end = pd.Timestamp(f"{end_year}-03-31")
    
    print(f"\nGenerating Projections from {forecast_start.strftime('%d-%b-%Y')} to {forecast_end.strftime('%d-%b-%Y')} ({horizon_years} fiscal years)...")
    if progress_callback:
        progress_callback(50, f"Generating multi-model projections ({forecast_start.strftime('%Y')} - {forecast_end.strftime('%Y')})...")
        
    forecast_dates = pd.date_range(start=forecast_start, end=forecast_end, freq='D')
    
    forecast_df = pd.DataFrame({'ACCOUNTING_DATE': forecast_dates})
    for name, m in models.items():
        col_name = name.upper().replace(" ", "_").replace("(", "").replace(")", "")
        forecast_df[col_name] = m.predict_dates(forecast_dates)
        
    ens_proj = ensemble.predict(forecast_start, forecast_end)
    forecast_df['FORECAST'] = forecast_df['OPTIMAL_WEIGHTED_ENSEMBLE']
    forecast_df['LOWER_80'] = ens_proj['LOWER_80']
    forecast_df['UPPER_80'] = ens_proj['UPPER_80']
    forecast_df['LOWER_95'] = ens_proj['LOWER_95']
    forecast_df['UPPER_95'] = ens_proj['UPPER_95']
    
    # 4. Out-of-sample Performance Evaluation on Holdout FY 2025-26
    df_holdout = df_daily[(df_daily['ACCOUNTING_DATE'] >= '2025-04-01') & (df_daily['ACCOUNTING_DATE'] <= '2026-03-31')].copy()
    if len(df_holdout) >= 300:
        print("\nEvaluating True Out-of-Sample Performance on Holdout Year FY 2025-26...")
        holdout_actuals = df_holdout['EXP_CRORES'].values
        holdout_preds = ensemble.predict_dates(df_holdout['ACCOUNTING_DATE'].values)
        holdout_metrics = compute_all_metrics(holdout_actuals, holdout_preds)
        print("Out-of-Sample FY 2025-26 Metrics (Optimal Ensemble):")
        for k, v in holdout_metrics.items():
            print(f"  {k}: {v}")
            
    # 5. Combined Dataset & Hierarchical Aggregations
    # Outer join to align actuals and forecasts by date
    merged_daily = pd.merge(
        df_daily.rename(columns={'EXP_CRORES': 'ACTUAL'}),
        forecast_df,
        on='ACCOUNTING_DATE',
        how='outer'
    ).sort_values('ACCOUNTING_DATE').reset_index(drop=True)
    
    val_cols = ['ACTUAL', 'FORECAST', 'LOWER_80', 'UPPER_80', 'LOWER_95', 'UPPER_95',
                'DAMPED_CAGR_BASELINE', 'STATISTICAL_HARMONIC', 'XGBOOST_REGRESSOR', 'DEEPDECOMPNET_PYTORCH']
                
    for vc in val_cols:
        if vc not in merged_daily.columns:
            merged_daily[vc] = 0.0
        else:
            merged_daily[vc] = merged_daily[vc].fillna(0.0)
            
    merged_daily.to_csv(os.path.join(CACHE_DIR, "daily_forecast.csv"), index=False)
    
    aggregations = {}
    for freq in ['Daily', 'Weekly', 'Monthly', 'Quarterly', 'Half-Yearly', 'Yearly']:
        agg_df = aggregate_time_series(merged_daily, freq=freq, date_col='ACCOUNTING_DATE', val_cols=val_cols)
        aggregations[freq] = agg_df
        agg_df.to_csv(os.path.join(CACHE_DIR, f"agg_{freq.lower().replace('-', '_')}.csv"), index=False)
        print(f"Generated {freq} aggregation: {len(agg_df)} rows")
        
    print("\nYearly Projections (FY 2024-25 Actuals through FY 2034-35 Forecasts):")
    yearly_summary = aggregations['Yearly'][['PERIOD_LABEL', 'ACTUAL', 'FORECAST', 'LOWER_80', 'UPPER_80']].tail(12)
    print(yearly_summary.to_string(index=False))
    
    # 6. Drift Report
    midpoint = len(df_train) // 2
    ref_data = df_train['EXP_CRORES'].iloc[:midpoint].values
    curr_data = df_train['EXP_CRORES'].iloc[midpoint:].values
    data_drift_report = compute_data_drift(ref_data, curr_data)
    
    in_sample_ens = ensemble.predict_dates(df_train['ACCOUNTING_DATE'])
    residuals = df_train['EXP_CRORES'].values - in_sample_ens
    model_drift_report = compute_model_drift(residuals)
    
    drift_summary = {
        "Data Drift": data_drift_report,
        "Model Drift": model_drift_report
    }
    with open(os.path.join(CACHE_DIR, "drift_report.json"), "w") as f:
        json.dump(drift_summary, f, indent=2)
        
    print("\nPipeline finished successfully!")
    return aggregations

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Retrain State Revenue Expenditure Forecasting Pipeline")
    parser.add_argument("--csv", type=str, default="CMN_ACTUAL_EXP_RCPT_TXN_filtered_1.csv", help="Path to input CSV transaction dataset")
    parser.add_argument("--cutoff", type=str, default="2025-03-31", help="Training cutoff date (YYYY-MM-DD), e.g. 2025-03-31")
    parser.add_argument("--horizon", type=int, default=10, help="Forecast horizon in fiscal years (default: 10)")
    args = parser.parse_args()
    
    run_pipeline(csv_path=args.csv, cutoff_date=args.cutoff, horizon_years=args.horizon)
