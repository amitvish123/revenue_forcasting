"""
Deep Learning Architecture: DeepDecompNet (PyTorch)
Learns non-linear fiscal seasonality R_t = Y_t / T_t.
Enforces fiscal annual seasonal conservation so sum over FY equals annual macro target.
"""
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
import numpy as np
import pandas as pd
from utils.calendar_utils import add_calendar_features, get_fiscal_year

class ResidualSeasonalNet(nn.Module):
    def __init__(self, input_dim=17, hidden_dim=64, dropout=0.15):
        super(ResidualSeasonalNet, self).__init__()
        
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.ln1 = nn.LayerNorm(hidden_dim)
        self.act1 = nn.GELU()
        self.drop1 = nn.Dropout(dropout)
        
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.ln2 = nn.LayerNorm(hidden_dim)
        self.act2 = nn.GELU()
        self.drop2 = nn.Dropout(dropout)
        
        self.fc3 = nn.Linear(hidden_dim, 32)
        self.ln3 = nn.LayerNorm(32)
        self.act3 = nn.GELU()
        
        self.out = nn.Linear(32, 1)
        
    def forward(self, x):
        h1 = self.drop1(self.act1(self.ln1(self.fc1(x))))
        h2 = h1 + self.drop2(self.act2(self.ln2(self.fc2(h1)))) # Skip connection
        h3 = self.act3(self.ln3(self.fc3(h2)))
        return self.out(h3)

class DeepDecompForecaster:
    def __init__(self, cagr_model=None, hidden_dim=64, lr=0.005, epochs=50, batch_size=64):
        self.cagr_model = cagr_model
        self.hidden_dim = hidden_dim
        self.lr = lr
        self.epochs = epochs
        self.batch_size = batch_size
        self.model = None
        self.mean_x = None
        self.std_x = None
        self.feature_cols = None
        self.residual_std = None
        
    def _extract_features(self, df):
        df_feat = add_calendar_features(df, date_col='ACCOUNTING_DATE')
        self.feature_cols = [
            'month', 'day', 'dayofweek', 'dayofyear', 'is_weekend',
            'is_month_start', 'is_month_end', 'fiscal_month',
            'is_march', 'is_march_end', 'is_march_31', 'is_budget_rush', 'is_q4',
            'month_sin', 'month_cos', 'dayofweek_sin', 'dayofweek_cos'
        ]
        return df_feat[self.feature_cols].values.astype(np.float32)

    def fit(self, df_daily, date_col='ACCOUNTING_DATE', val_col='EXP_CRORES', cagr_model=None):
        if cagr_model is not None:
            self.cagr_model = cagr_model
            
        df = df_daily.sort_values(date_col).reset_index(drop=True)
        X = self._extract_features(df)
        
        trend = self.cagr_model.get_macro_trend(df[date_col])
        ratio = df[val_col].values / (trend + 1e-4)
        y_log_ratio = np.log(np.clip(ratio, 0.001, 50.0)).astype(np.float32).reshape(-1, 1)
        
        self.mean_x = np.mean(X, axis=0, keepdims=True)
        self.std_x = np.std(X, axis=0, keepdims=True) + 1e-6
        X_scaled = (X - self.mean_x) / self.std_x
        
        tensor_x = torch.from_numpy(X_scaled)
        tensor_y = torch.from_numpy(y_log_ratio)
        dataset = TensorDataset(tensor_x, tensor_y)
        loader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True)
        
        self.model = ResidualSeasonalNet(input_dim=X.shape[1], hidden_dim=self.hidden_dim, dropout=0.15)
        criterion = nn.SmoothL1Loss()
        optimizer = optim.Adam(self.model.parameters(), lr=self.lr, weight_decay=1e-4)
        
        self.model.train()
        for epoch in range(self.epochs):
            for bx, by in loader:
                optimizer.zero_grad()
                pred = self.model(bx)
                loss = criterion(pred, by)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                optimizer.step()
                
        preds = self.predict_dates(df[date_col])
        self.residual_std = float(np.std(df[val_col].values - preds))
        return self

    def predict_dates(self, date_series):
        dates = pd.to_datetime(pd.Series(date_series)).reset_index(drop=True)
        df_dates = pd.DataFrame({'ACCOUNTING_DATE': dates})
        X = self._extract_features(df_dates)
        X_scaled = (X - self.mean_x) / self.std_x
        
        self.model.eval()
        with torch.no_grad():
            log_mult = self.model(torch.from_numpy(X_scaled)).numpy().flatten()
            raw_mult = np.exp(np.clip(log_mult, -4.0, 3.5))
            
        # Seasonal conservation: normalize multipliers so average daily multiplier per FY is 1.0
        df_temp = pd.DataFrame({'ACCOUNTING_DATE': dates, 'RAW_MULT': raw_mult})
        df_temp['FY'] = df_temp['ACCOUNTING_DATE'].apply(get_fiscal_year)
        fy_means = df_temp.groupby('FY')['RAW_MULT'].transform('mean')
        norm_mult = df_temp['RAW_MULT'] / (fy_means + 1e-6)
        
        trend = self.cagr_model.get_macro_trend(dates)
        preds = trend * norm_mult.values
        return np.maximum(0.01, preds)

    def predict(self, start_date, end_date):
        date_range = pd.date_range(start=start_date, end=end_date, freq='D')
        mean_preds = self.predict_dates(date_range)
        
        days_ahead = np.arange(1, len(date_range) + 1)
        sigma = self.residual_std * np.sqrt(1 + 0.03 * (days_ahead / 365.25))
        
        lower_80 = np.clip(mean_preds - 1.28 * sigma, 0.0, None)
        upper_80 = mean_preds + 1.28 * sigma
        lower_95 = np.clip(mean_preds - 1.96 * sigma, 0.0, None)
        upper_95 = mean_preds + 1.96 * sigma
        
        return pd.DataFrame({
            'ACCOUNTING_DATE': date_range,
            'FORECAST': mean_preds,
            'LOWER_80': lower_80,
            'UPPER_80': upper_80,
            'LOWER_95': lower_95,
            'UPPER_95': upper_95
        })
