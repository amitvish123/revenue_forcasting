"""
Statistical Harmonic Baseline
"""
import numpy as np
import pandas as pd
from utils.calendar_utils import add_calendar_features

class StatisticalHarmonicForecaster:
    def __init__(self, cagr_model=None, harmonics=4):
        self.cagr_model = cagr_model
        self.harmonics = harmonics
        self.weights = None
        self.std_residual = None
        
    def _fourier_terms(self, days, period=365.25):
        features = []
        for i in range(1, self.harmonics + 1):
            features.append(np.sin(2 * np.pi * i * days / period))
            features.append(np.cos(2 * np.pi * i * days / period))
        features.append(np.sin(2 * np.pi * days / 7.0))
        features.append(np.cos(2 * np.pi * days / 7.0))
        return np.column_stack(features)

    def fit(self, df_daily, date_col='ACCOUNTING_DATE', val_col='EXP_CRORES', cagr_model=None):
        if cagr_model is not None:
            self.cagr_model = cagr_model
            
        df = df_daily.sort_values(date_col).reset_index(drop=True)
        t = np.arange(len(df))
        X_fourier = self._fourier_terms(t)
        
        df_feat = add_calendar_features(df, date_col=date_col)
        is_march = df_feat['is_march'].values.reshape(-1, 1)
        is_march_end = df_feat['is_march_end'].values.reshape(-1, 1)
        
        X = np.hstack([np.ones((len(df), 1)), X_fourier, is_march, is_march_end])
        trend = self.cagr_model.get_macro_trend(df[date_col])
        ratio = df[val_col].values / (trend + 1e-4)
        y_log_ratio = np.log(np.clip(ratio, 0.001, 50.0))
        
        reg = 1e-2 * np.eye(X.shape[1])
        reg[0, 0] = 0.0
        self.weights = np.linalg.solve(X.T @ X + reg, X.T @ y_log_ratio)
        self.start_date = df[date_col].min()
        
        preds = self.predict_dates(df[date_col])
        self.std_residual = float(np.std(df[val_col].values - preds))
        return self

    def predict_dates(self, date_series):
        dates = pd.to_datetime(pd.Series(date_series)).reset_index(drop=True)
        t = (dates - self.start_date).dt.days.values
        X_fourier = self._fourier_terms(t)
        
        df_dates = pd.DataFrame({'ACCOUNTING_DATE': dates})
        df_feat = add_calendar_features(df_dates, date_col='ACCOUNTING_DATE')
        is_march = df_feat['is_march'].values.reshape(-1, 1)
        is_march_end = df_feat['is_march_end'].values.reshape(-1, 1)
        
        X = np.hstack([np.ones((len(dates), 1)), X_fourier, is_march, is_march_end])
        log_mult = X @ self.weights
        mult = np.exp(np.clip(log_mult, -4.0, 3.5))
        trend = self.cagr_model.get_macro_trend(dates)
        return np.maximum(0.01, trend * mult)

    def predict(self, start_date, end_date):
        date_range = pd.date_range(start=start_date, end=end_date, freq='D')
        mean_preds = self.predict_dates(date_range)
        
        days_ahead = np.arange(1, len(date_range) + 1)
        sigma = self.std_residual * np.sqrt(1 + 0.03 * (days_ahead / 365.25))
        
        lower_80 = np.clip(mean_preds - 1.28 * sigma, 0.0, None)
        upper_80 = mean_preds + 1.28 * sigma
        lower_95 = np.clip(mean_preds - 1.96 * sigma, 0.0, None)
        upper_95 = mean_preds + 1.96 * sigma
        
        return pd.DataFrame({
            'ACCOUNTING_DATE': date_range,
            'FORECAST': mean_preds,
            'LOWER_80': lower_80,
            'UPPER_80': upper_80,
            'LOWER_95': lower_95,
            'UPPER_95': upper_95
        })
