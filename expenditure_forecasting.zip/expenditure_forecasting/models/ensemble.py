"""
Ensemble Forecaster: Optimal Constrained Weighted Blend
Finds weights w_i >= 0, sum(w_i) = 1 to minimize cross-validation WAPE / RMSE.
"""
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from validation.metrics import calculate_wape

class OptimalWeightedEnsemble:
    def __init__(self, models_dict=None):
        """
        models_dict: dict of {name: model_instance}
        """
        self.models = models_dict or {}
        self.weights = {}
        self.model_names = list(self.models.keys())
        self.residual_std = None

    def optimize_weights(self, y_true, model_predictions_dict):
        """
        Find weights that minimize WAPE on validation set
        """
        y_true = np.asarray(y_true, dtype=float)
        self.model_names = list(model_predictions_dict.keys())
        n_models = len(self.model_names)
        
        # Matrix of predictions: shape (N, n_models)
        pred_matrix = np.column_stack([model_predictions_dict[m] for m in self.model_names])
        
        def objective(w):
            ens_pred = pred_matrix @ w
            return calculate_wape(y_true, ens_pred)
            
        # Initial guess: equal weights
        w0 = np.ones(n_models) / n_models
        # Bounds: 0 <= w_i <= 1
        bounds = [(0.0, 1.0) for _ in range(n_models)]
        # Constraint: sum(w_i) = 1
        constraints = ({'type': 'eq', 'fun': lambda w: np.sum(w) - 1.0})
        
        res = minimize(objective, w0, method='SLSQP', bounds=bounds, constraints=constraints)
        
        if res.success:
            opt_weights = np.round(res.x, 4)
            # Renormalize to ensure exact 1.0 sum
            opt_weights = opt_weights / np.sum(opt_weights)
        else:
            opt_weights = w0
            
        self.weights = dict(zip(self.model_names, opt_weights))
        
        # Calculate ensemble residuals
        best_ens_preds = pred_matrix @ opt_weights
        residuals = y_true - best_ens_preds
        self.residual_std = float(np.std(residuals))
        
        return self.weights

    def predict_dates(self, date_series):
        dates = pd.to_datetime(pd.Series(date_series)).reset_index(drop=True)
        pred_matrix = np.column_stack([self.models[m].predict_dates(dates) for m in self.model_names])
        w = np.array([self.weights[m] for m in self.model_names])
        return pred_matrix @ w

    def predict(self, start_date, end_date):
        date_range = pd.date_range(start=start_date, end=end_date, freq='D')
        mean_preds = self.predict_dates(date_range)
        
        days_ahead = np.arange(1, len(date_range) + 1)
        sigma = self.residual_std * np.sqrt(1 + 0.04 * (days_ahead / 365.25))
        
        lower_80 = np.clip(mean_preds - 1.28 * sigma, 0.0, None)
        upper_80 = mean_preds + 1.28 * sigma
        lower_95 = np.clip(mean_preds - 1.96 * sigma, 0.0, None)
        upper_95 = mean_preds + 1.96 * sigma
        
        return pd.DataFrame({
            'ACCOUNTING_DATE': date_range,
            'FORECAST': mean_preds,
            'LOWER_80': lower_80,
            'UPPER_80': upper_80,
            'LOWER_95': lower_95,
            'UPPER_95': upper_95
        })
