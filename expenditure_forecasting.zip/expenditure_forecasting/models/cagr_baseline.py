"""
Damped CAGR Baseline & Trend Decomposition Engine
Fits on historical fiscal years up to 31-03-2025.
Provides:
1. Macro Annual Trend Projection (T_t) without excessive damping
2. Intra-year daily seasonal profile S_d (d in 1..366) and day-of-week multipliers
3. Smooth fiscal year continuation from FY 2024-25 onwards
"""
import numpy as np
import pandas as pd
from utils.calendar_utils import get_fiscal_year

class DampedCAGRForecaster:
    def __init__(self, damping_factor=0.99, min_growth_rate=0.07):
        """
        damping_factor: annual decay applied to growth rate (0.99 for gentle, realistic damping)
        min_growth_rate: nominal floor (inflation + baseline state expansion)
        """
        self.damping_factor = damping_factor
        self.min_growth_rate = min_growth_rate
        self.cagr = None
        self.base_fy = None
        self.base_fy_annual_total = None
        self.day_of_fy_weights = None
        self.dow_weights = None
        self.residual_std = None
        
    def fit(self, df_daily, date_col='ACCOUNTING_DATE', val_col='EXP_CRORES'):
        df = df_daily.copy()
        df[date_col] = pd.to_datetime(df[date_col])
        df['FY'] = df[date_col].apply(get_fiscal_year)
        
        # Aggregate full fiscal years (>= 300 days)
        fy_totals = df.groupby('FY')[val_col].agg(['sum', 'count'])
        full_fys = fy_totals[fy_totals['count'] >= 300].sort_index()
        
        if len(full_fys) >= 2:
            first_val = full_fys['sum'].iloc[0]
            last_val = full_fys['sum'].iloc[-1]
            num_years = len(full_fys) - 1
            raw_cagr = (last_val / first_val) ** (1.0 / num_years) - 1.0
            # Clip CAGR to realistic economic bounds [7%, 14%]
            self.cagr = max(self.min_growth_rate, min(0.14, raw_cagr))
            self.base_fy = full_fys.index[-1]
            self.base_fy_annual_total = last_val
        else:
            self.cagr = 0.11
            self.base_fy = fy_totals.index[-1]
            self.base_fy_annual_total = fy_totals['sum'].iloc[-1]
            
        # Intra-year daily seasonality profile: Day of fiscal year (1 = April 1, 365/366 = March 31)
        def get_dofy(dt):
            fy_start_year = dt.year if dt.month >= 4 else dt.year - 1
            fy_start = pd.Timestamp(year=fy_start_year, month=4, day=1)
            return (dt - fy_start).days + 1
            
        df['DOFY'] = df[date_col].apply(get_dofy)
        
        # Calculate daily normalized weight relative to annual daily mean
        df['DAILY_AVG_ANNUAL'] = df['FY'].map(full_fys['sum'] / 365.25)
        df['DAILY_AVG_ANNUAL'] = df['DAILY_AVG_ANNUAL'].fillna(self.base_fy_annual_total / 365.25)
        df['NORM_WEIGHT'] = df[val_col] / (df['DAILY_AVG_ANNUAL'] + 1e-6)
        
        dofy_weights = df.groupby('DOFY')['NORM_WEIGHT'].median()
        all_dofy = pd.Series(index=range(1, 367), dtype=float)
        all_dofy.update(dofy_weights)
        all_dofy = all_dofy.interpolate(method='linear').bfill().ffill()
        self.day_of_fy_weights = all_dofy / all_dofy.mean()
        
        # Day of week adjustment
        df['DOW'] = df[date_col].dt.dayofweek
        dow_weights = df.groupby('DOW')['NORM_WEIGHT'].mean()
        self.dow_weights = dow_weights / dow_weights.mean()
        
        # Train residual variance
        predicted_train = self.predict_dates(df[date_col])
        residuals = df[val_col].values - predicted_train
        self.residual_std = float(np.std(residuals))
        
        return self

    def get_annual_target_for_fy(self, fy_year):
        """
        fy_year: integer starting year of FY, e.g. 2025 for FY 2025-26
        Base year: starting year of base FY (e.g. 2024 for FY 2024-25)
        """
        base_year = int(self.base_fy.split('-')[0].replace('FY ', '').strip())
        year_diff = fy_year - base_year
        
        annual_target = self.base_fy_annual_total
        if year_diff > 0:
            for k in range(1, year_diff + 1):
                growth = max(self.min_growth_rate, self.cagr * (self.damping_factor ** (k - 1)))
                annual_target *= (1.0 + growth)
        elif year_diff < 0:
            for k in range(abs(year_diff)):
                annual_target /= (1.0 + self.cagr)
        return annual_target

    def get_macro_trend(self, date_series):
        """
        Returns the baseline daily trend T_t for given dates
        """
        dates = pd.to_datetime(pd.Series(date_series)).reset_index(drop=True)
        trends = []
        for dt in dates:
            fy_year = dt.year if dt.month >= 4 else dt.year - 1
            annual_target = self.get_annual_target_for_fy(fy_year)
            trends.append(annual_target / 365.25)
        return np.array(trends)

    def predict_dates(self, date_series):
        dates = pd.to_datetime(pd.Series(date_series)).reset_index(drop=True)
        preds = []
        for dt in dates:
            fy_year = dt.year if dt.month >= 4 else dt.year - 1
            annual_target = self.get_annual_target_for_fy(fy_year)
            daily_mean = annual_target / 365.25
            
            fy_start = pd.Timestamp(year=fy_year, month=4, day=1)
            dofy = (dt - fy_start).days + 1
            dofy = max(1, min(366, dofy))
            
            season_mult = self.day_of_fy_weights.get(dofy, 1.0)
            dow_mult = self.dow_weights.get(dt.dayofweek, 1.0)
            
            pred = daily_mean * season_mult * (0.85 + 0.15 * dow_mult)
            if dt.month == 3 and dt.day == 31:
                pred = max(pred, daily_mean * 12.0)
            preds.append(max(0.01, pred))
            
        return np.array(preds)

    def predict(self, start_date, end_date):
        date_range = pd.date_range(start=start_date, end=end_date, freq='D')
        mean_preds = self.predict_dates(date_range)
        
        days_ahead = np.arange(1, len(date_range) + 1)
        sigma = self.residual_std * np.sqrt(1 + 0.03 * (days_ahead / 365.25))
        
        lower_80 = np.clip(mean_preds - 1.28 * sigma, 0.0, None)
        upper_80 = mean_preds + 1.28 * sigma
        lower_95 = np.clip(mean_preds - 1.96 * sigma, 0.0, None)
        upper_95 = mean_preds + 1.96 * sigma
        
        return pd.DataFrame({
            'ACCOUNTING_DATE': date_range,
            'FORECAST': mean_preds,
            'LOWER_80': lower_80,
            'UPPER_80': upper_80,
            'LOWER_95': lower_95,
            'UPPER_95': upper_95
        })
