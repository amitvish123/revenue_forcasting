"""
GBDT Benchmark Models: XGBoost Regressor
Learns non-linear seasonality on top of CAGR Macro Trend.
Enforces fiscal annual seasonal conservation so sum over FY equals annual macro target.
"""
import numpy as np
import pandas as pd
import xgboost as xgb
from utils.calendar_utils import add_calendar_features, get_fiscal_year

class XGBoostForecaster:
    def __init__(self, cagr_model=None, n_estimators=180, max_depth=5, learning_rate=0.05):
        self.cagr_model = cagr_model
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.learning_rate = learning_rate
        self.model = None
        self.feature_names = None
        self.feature_importances_ = None
        self.std_residual = None

    def _prepare_features(self, df):
        df_feat = add_calendar_features(df, date_col='ACCOUNTING_DATE')
        feature_cols = [
            'month', 'day', 'dayofweek', 'dayofyear', 'is_weekend',
            'is_month_start', 'is_month_end', 'fiscal_month',
            'is_march', 'is_march_end', 'is_march_31', 'is_budget_rush', 'is_q4',
            'month_sin', 'month_cos', 'dayofweek_sin', 'dayofweek_cos',
            'dayofyear_sin', 'dayofyear_cos'
        ]
        return df_feat[feature_cols].copy(), feature_cols

    def fit(self, df_daily, date_col='ACCOUNTING_DATE', val_col='EXP_CRORES', cagr_model=None):
        if cagr_model is not None:
            self.cagr_model = cagr_model
            
        df = df_daily.sort_values(date_col).reset_index(drop=True)
        X, feature_cols = self._prepare_features(df)
        self.feature_names = feature_cols
        
        trend = self.cagr_model.get_macro_trend(df[date_col])
        ratio = df[val_col].values / (trend + 1e-4)
        y_log_ratio = np.log(np.clip(ratio, 0.001, 50.0))
        
        self.model = xgb.XGBRegressor(
            n_estimators=self.n_estimators,
            max_depth=self.max_depth,
            learning_rate=self.learning_rate,
            subsample=0.85,
            colsample_bytree=0.85,
            random_state=42,
            n_jobs=-1
        )
        self.model.fit(X, y_log_ratio)
        self.feature_importances_ = dict(zip(self.feature_names, self.model.feature_importances_))
        
        preds = self.predict_dates(df[date_col])
        residuals = df[val_col].values - preds
        self.std_residual = float(np.std(residuals))
        return self

    def predict_dates(self, date_series):
        dates = pd.to_datetime(pd.Series(date_series)).reset_index(drop=True)
        df_dates = pd.DataFrame({'ACCOUNTING_DATE': dates})
        X, _ = self._prepare_features(df_dates)
        log_mult = self.model.predict(X)
        raw_mult = np.exp(np.clip(log_mult, -4.0, 3.5))
        
        # Seasonal conservation
        df_temp = pd.DataFrame({'ACCOUNTING_DATE': dates, 'RAW_MULT': raw_mult})
        df_temp['FY'] = df_temp['ACCOUNTING_DATE'].apply(get_fiscal_year)
        fy_means = df_temp.groupby('FY')['RAW_MULT'].transform('mean')
        norm_mult = df_temp['RAW_MULT'] / (fy_means + 1e-6)
        
        trend = self.cagr_model.get_macro_trend(dates)
        return np.maximum(0.01, trend * norm_mult.values)

    def predict(self, start_date, end_date):
        date_range = pd.date_range(start=start_date, end=end_date, freq='D')
        mean_preds = self.predict_dates(date_range)
        
        days_ahead = np.arange(1, len(date_range) + 1)
        sigma = self.std_residual * np.sqrt(1 + 0.03 * (days_ahead / 365.25))
        
        lower_80 = np.clip(mean_preds - 1.28 * sigma, 0.0, None)
        upper_80 = mean_preds + 1.28 * sigma
        lower_95 = np.clip(mean_preds - 1.96 * sigma, 0.0, None)
        upper_95 = mean_preds + 1.96 * sigma
        
        return pd.DataFrame({
            'ACCOUNTING_DATE': date_range,
            'FORECAST': mean_preds,
            'LOWER_80': lower_80,
            'UPPER_80': upper_80,
            'LOWER_95': lower_95,
            'UPPER_95': upper_95
        })
