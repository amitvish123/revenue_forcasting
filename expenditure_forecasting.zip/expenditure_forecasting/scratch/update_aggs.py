import pandas as pd
from utils.aggregation import aggregate_time_series

merged_daily = pd.read_csv("data_cache/daily_forecast.csv")
merged_daily['ACCOUNTING_DATE'] = pd.to_datetime(merged_daily['ACCOUNTING_DATE'])

val_cols = ['ACTUAL', 'FORECAST', 'LOWER_80', 'UPPER_80', 'LOWER_95', 'UPPER_95',
            'DAMPED_CAGR_BASELINE', 'STATISTICAL_HARMONIC', 'XGBOOST_REGRESSOR', 'DEEPDECOMPNET_PYTORCH']

for freq in ['Daily', 'Weekly', 'Monthly', 'Quarterly', 'Half-Yearly', 'Yearly']:
    agg_df = aggregate_time_series(merged_daily, freq=freq, date_col='ACCOUNTING_DATE', val_cols=val_cols)
    agg_df.to_csv(f"data_cache/agg_{freq.lower().replace('-', '_')}.csv", index=False)
    print(f"Updated {freq} aggregation: {len(agg_df)} rows")

yearly = pd.read_csv("data_cache/agg_yearly.csv")
print("\nUpdated Clean Yearly Table:")
print(yearly[['PERIOD_LABEL', 'ACTUAL', 'FORECAST']])
