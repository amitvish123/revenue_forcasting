import sys
sys.path.append('.')
import pandas as pd
import numpy as np
from utils.calendar_utils import get_fiscal_year
from models.cagr_baseline import DampedCAGRForecaster

df = pd.read_csv('CMN_ACTUAL_EXP_RCPT_TXN_filtered_1.csv')
df['ACCOUNTING_DATE'] = pd.to_datetime(df['ACCOUNTING_DATE'], format='%d-%m-%Y %H:%M')
df_train = df[df['ACCOUNTING_DATE'] <= '2025-03-31'].copy()
df_train['EXP_CRORES'] = df_train['NET_EXP'] / 1e7

cagr_model = DampedCAGRForecaster(damping_factor=0.99, min_growth_rate=0.08).fit(df_train)
print("CAGR fitted:", cagr_model.cagr)
print("Base FY 2024-25 total:", cagr_model.base_fy_annual_total)

dates_10y = pd.date_range('2025-04-01', '2035-03-31', freq='D')
cagr_preds = cagr_model.predict_dates(dates_10y)

df_fc = pd.DataFrame({'ACCOUNTING_DATE': dates_10y, 'PRED': cagr_preds})
df_fc['FY'] = df_fc['ACCOUNTING_DATE'].apply(get_fiscal_year)
annual_fc = df_fc.groupby('FY')['PRED'].sum()
print("\nAnnual Projections with Seasonal Conservation:")
for fy, val in annual_fc.items():
    print(f"  {fy}: {val:,.2f} Cr")
