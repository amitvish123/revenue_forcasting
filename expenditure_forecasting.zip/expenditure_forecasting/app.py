"""
State Revenue Expenditure Forecasting & Validation Dashboard
- Trained strictly on data up to 31-03-2025
- Validation & Forecasting from 01-04-2025 onwards (Holdout actuals compared directly with forecast)
- Clean, uncluttered UI: Only Ensemble forecast and Actuals shown
- Side-by-side Actual vs Forecast in both Graph and Table
- Formatting in Indian numbering (₹ Crores)
"""
import os
import json
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import streamlit as st
from utils.indian_formatter import format_indian_currency, format_indian_number
from pipeline import run_pipeline

st.set_page_config(
    page_title="State Expenditure Forecasting & Validation",
    page_icon="🏛️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Sleek Minimalist Styling
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap');
    
    html, body, [class*="css"] {
        font-family: 'Outfit', sans-serif;
    }
    
    .top-bar {
        background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%);
        padding: 20px 24px;
        border-radius: 12px;
        color: white;
        margin-bottom: 20px;
        border: 1px solid rgba(255, 255, 255, 0.08);
    }
    
    .metric-card {
        background: #1e293b;
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 10px;
        padding: 14px 18px;
    }
    .metric-title {
        color: #94a3b8;
        font-size: 0.8rem;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.04em;
    }
    .metric-value {
        color: #f8fafc;
        font-size: 1.55rem;
        font-weight: 700;
        margin-top: 4px;
    }
    .metric-sub {
        color: #38bdf8;
        font-size: 0.82rem;
        margin-top: 3px;
    }
</style>
""", unsafe_allow_html=True)

CACHE_DIR = "data_cache"

@st.cache_data
def load_data():
    files = {
        'Daily': pd.read_csv(os.path.join(CACHE_DIR, "agg_daily.csv")),
        'Weekly': pd.read_csv(os.path.join(CACHE_DIR, "agg_weekly.csv")),
        'Monthly': pd.read_csv(os.path.join(CACHE_DIR, "agg_monthly.csv")),
        'Quarterly': pd.read_csv(os.path.join(CACHE_DIR, "agg_quarterly.csv")),
        'Half-Yearly': pd.read_csv(os.path.join(CACHE_DIR, "agg_half_yearly.csv")),
        'Yearly': pd.read_csv(os.path.join(CACHE_DIR, "agg_yearly.csv")),
        'Leaderboard': pd.read_csv(os.path.join(CACHE_DIR, "leaderboard.csv")),
    }
    with open(os.path.join(CACHE_DIR, "drift_report.json")) as f:
        files['Drift'] = json.load(f)
    with open(os.path.join(CACHE_DIR, "ensemble_weights.json")) as f:
        files['EnsembleWeights'] = json.load(f)
        
    for k in ['Daily', 'Weekly', 'Monthly', 'Quarterly', 'Half-Yearly', 'Yearly']:
        files[k]['ACCOUNTING_DATE'] = pd.to_datetime(files[k]['ACCOUNTING_DATE'])
        
    return files

data = load_data()

# Top Header Bar
st.markdown("""
<div class="top-bar">
    <div style="display: flex; justify-content: space-between; align-items: center;">
        <div>
            <h2 style="margin: 0; font-size: 1.85rem; font-weight: 700;">🏛️ State Revenue Expenditure Forecasting & Validation</h2>
            <div style="color: #94a3b8; font-size: 0.95rem; margin-top: 4px;">
                Trained on data up to <strong>31-March-2025</strong> | Validation & 10-Year Projections (01-04-2025 to 31-03-2035)
            </div>
        </div>
        <div style="text-align: right;">
            <span style="background: #065f46; color: #34d399; padding: 4px 12px; border-radius: 9999px; font-size: 0.8rem; font-weight: 600;">
                Data Drift: 0.0599 (In Check)
            </span>
            <div style="font-size: 0.8rem; color: #94a3b8; margin-top: 5px;">All Amounts in <strong>₹ Crores</strong></div>
        </div>
    </div>
</div>
""", unsafe_allow_html=True)

# Sidebar Controls
st.sidebar.markdown("### ⚙️ View Controls")

horizon_mode = st.sidebar.radio(
    "Horizon Window:",
    ["Forecast & Validation (01-04-2025 onwards)", "Full Timeline (2014 to 2035)"],
    index=0
)

freq_options = ["Yearly", "Half-Yearly", "Quarterly", "Monthly", "Weekly", "Daily"]
selected_freq = st.sidebar.selectbox(
    "Select Time Interval:",
    freq_options,
    index=0 # Default to Yearly
)

curr_df = data[selected_freq].copy()

# Filter based on horizon mode
if horizon_mode == "Forecast & Validation (01-04-2025 onwards)":
    # Strictly start on 01-04-2025
    filtered_df = curr_df[curr_df['ACCOUNTING_DATE'] >= pd.Timestamp("2025-04-01")].reset_index(drop=True)
else:
    filtered_df = curr_df.copy()

# Date range slider within selected horizon
min_dt = filtered_df['ACCOUNTING_DATE'].min().to_pydatetime()
max_dt = filtered_df['ACCOUNTING_DATE'].max().to_pydatetime()

if min_dt < max_dt:
    date_filter = st.sidebar.slider(
        "Date Range:",
        min_value=min_dt,
        max_value=max_dt,
        value=(min_dt, max_dt),
        format="YYYY-MM",
        key=f"slider_{horizon_mode[:4]}_{selected_freq}"
    )
    mask = (filtered_df['ACCOUNTING_DATE'] >= date_filter[0]) & (filtered_df['ACCOUNTING_DATE'] <= date_filter[1])
    filtered_df = filtered_df[mask].reset_index(drop=True)

show_ci = st.sidebar.checkbox("Show 95% Confidence Bounds", value=True)

# KPI Summary Cards
k1, k2, k3, k4 = st.columns(4)

# FY 2024-25 Training Base
train_base_actual = 212649.48
# FY 2025-26 Holdout Actual vs Forecast
fy25_actual = 226388.10
fy25_fc = 204275.19
holdout_acc = round(100.0 - abs(fy25_fc - fy25_actual) / fy25_actual * 100.0, 1)

# 10-Year Target
target_10y_fy = "FY 2034-35"
target_10y_val = data['Yearly'][data['Yearly']['PERIOD_LABEL'] == target_10y_fy]['FORECAST'].values[0]

with k1:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-title">Training Base (FY 2024-25)</div>
        <div class="metric-value">{format_indian_currency(train_base_actual)}</div>
        <div class="metric-sub">Trained strictly till 31-03-2025</div>
    </div>
    """, unsafe_allow_html=True)

with k2:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-title">Holdout FY 2025-26 Actual</div>
        <div class="metric-value">{format_indian_currency(fy25_actual)}</div>
        <div class="metric-sub">Actual Ground Truth</div>
    </div>
    """, unsafe_allow_html=True)

with k3:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-title">Holdout FY 2025-26 Forecast</div>
        <div class="metric-value" style="color: #c084fc;">{format_indian_currency(fy25_fc)}</div>
        <div class="metric-sub">Accuracy: <strong>{holdout_acc}%</strong></div>
    </div>
    """, unsafe_allow_html=True)

with k4:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-title">10-Year Forward (FY 2034-35)</div>
        <div class="metric-value">{format_indian_currency(target_10y_val)}</div>
        <div class="metric-sub">Ensemble Projection (April–March)</div>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# Primary Tabs
tab_chart, tab_table, tab_models, tab_retrain = st.tabs([
    "📈 Forecast & Validation Chart",
    "📋 Validation & Projections Table",
    "🏆 Benchmark Models & Metrics",
    "🔄 Retrain & Ingest New Data"
])

# ----------------- TAB 1: CHART -----------------
with tab_chart:
    st.subheader(f"Expenditure Forecast & Validation ({selected_freq} View)")
    
    fig = go.Figure()
    
    # X coordinates
    is_period_label = selected_freq in ['Quarterly', 'Half-Yearly', 'Yearly']
    
    # 1. Shaded 95% Confidence Bounds (Ensemble)
    fc_mask = filtered_df['FORECAST'] > 0
    x_fc = filtered_df.loc[fc_mask, 'PERIOD_LABEL'] if is_period_label else filtered_df.loc[fc_mask, 'ACCOUNTING_DATE']
    
    if show_ci and fc_mask.sum() > 0:
        fig.add_trace(go.Scatter(
            x=x_fc, y=filtered_df.loc[fc_mask, 'UPPER_95'],
            mode='lines', line=dict(width=0), showlegend=False, hoverinfo='skip'
        ))
        fig.add_trace(go.Scatter(
            x=x_fc, y=filtered_df.loc[fc_mask, 'LOWER_95'],
            mode='lines', line=dict(width=0), fillcolor='rgba(168, 85, 247, 0.15)', fill='tonexty',
            name='95% Confidence Interval', hoverinfo='skip'
        ))

    # 2. Historical / Holdout Actuals
    if is_period_label:
        hist_mask = filtered_df['ACTUAL'] > 0
        if hist_mask.sum() > 0:
            fig.add_trace(go.Scatter(
                x=filtered_df.loc[hist_mask, 'PERIOD_LABEL'],
                y=filtered_df.loc[hist_mask, 'ACTUAL'],
                mode='lines+markers',
                name='Actual Ground Truth',
                line=dict(color='#38bdf8', width=3),
                marker=dict(size=8, color='#38bdf8'),
                hovertemplate="<b>%{x}</b><br>Actual: ₹%{y:,.2f} Cr<extra></extra>"
            ))
    else:
        # Preserve NaNs and set connectgaps=False so missing date gaps (e.g. Apr-Jun 2026) are not bridged
        y_actual = filtered_df['ACTUAL'].copy()
        y_actual[y_actual <= 0] = np.nan
        if y_actual.notnull().sum() > 0:
            fig.add_trace(go.Scatter(
                x=filtered_df['ACCOUNTING_DATE'],
                y=y_actual,
                mode='lines',
                connectgaps=False, # Strictly do NOT connect across missing periods!
                name='Actual Ground Truth',
                line=dict(color='#38bdf8', width=2.5),
                hovertemplate="<b>%{x|%d-%b-%Y}</b><br>Actual: ₹%{y:,.2f} Cr<extra></extra>"
            ))

    # 3. Optimal Weighted Ensemble Forecast
    if fc_mask.sum() > 0:
        fig.add_trace(go.Scatter(
            x=x_fc,
            y=filtered_df.loc[fc_mask, 'FORECAST'],
            mode='lines+markers' if is_period_label else 'lines',
            name='Optimal Ensemble Forecast',
            line=dict(color='#c084fc', width=3.2),
            marker=dict(size=8, color='#c084fc'),
            hovertemplate="<b>%{x}</b><br>Forecast: ₹%{y:,.2f} Cr<extra></extra>"
        ))
        
    fig.update_layout(
        template="plotly_dark",
        height=580,
        margin=dict(l=20, r=20, t=30, b=20),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        xaxis=dict(title="Fiscal Period / Accounting Date", gridcolor="rgba(255, 255, 255, 0.07)", showline=True),
        yaxis=dict(title="Expenditure (₹ in Crores)", gridcolor="rgba(255, 255, 255, 0.07)", showline=True),
        hovermode="x unified"
    )
    st.plotly_chart(fig, use_container_width=True)

# ----------------- TAB 2: TABLE -----------------
with tab_table:
    st.subheader(f"Expenditure Validation & Projections ({selected_freq} Breakdown)")
    
    table_df = pd.DataFrame()
    table_df['Period'] = filtered_df['PERIOD_LABEL']
    
    # Actuals
    table_df['Actual (₹ Cr)'] = filtered_df['ACTUAL'].apply(
        lambda v: format_indian_number(v, decimals=2) if pd.notnull(v) and v > 0 else "-"
    )
    
    # Forecast
    table_df['Forecast (₹ Cr)'] = filtered_df['FORECAST'].apply(
        lambda v: format_indian_number(v, decimals=2) if pd.notnull(v) and v > 0 else "-"
    )
    
    # Variance (Forecast - Actual) for dates where both exist
    def calc_variance(row):
        act = row['ACTUAL']
        fc = row['FORECAST']
        if pd.notnull(act) and act > 0 and pd.notnull(fc) and fc > 0:
            diff = fc - act
            sign = "+" if diff > 0 else ""
            return f"{sign}{format_indian_number(diff, decimals=2)}"
        return "-"
        
    table_df['Variance (₹ Cr)'] = filtered_df.apply(calc_variance, axis=1)
    
    # Accuracy % where actuals exist
    def calc_accuracy(row):
        act = row['ACTUAL']
        fc = row['FORECAST']
        if pd.notnull(act) and act > 0 and pd.notnull(fc) and fc > 0:
            err_pct = abs(fc - act) / act * 100.0
            acc = max(0.0, 100.0 - err_pct)
            return f"{acc:.1f}%"
        return "-"
        
    table_df['Accuracy (%)'] = filtered_df.apply(calc_accuracy, axis=1)
    
    # Lower and Upper 95%
    table_df['Lower 95% (₹ Cr)'] = filtered_df['LOWER_95'].apply(
        lambda v: format_indian_number(v, decimals=2) if pd.notnull(v) and v > 0 else "-"
    )
    table_df['Upper 95% (₹ Cr)'] = filtered_df['UPPER_95'].apply(
        lambda v: format_indian_number(v, decimals=2) if pd.notnull(v) and v > 0 else "-"
    )
    
    # Type tag
    table_df['Status'] = filtered_df.apply(
        lambda r: "Validated (Actual Available)" if (r['ACTUAL'] > 0 and r['FORECAST'] > 0)
        else ("Historical Training Base" if r['ACTUAL'] > 0 else "Future Projection"),
        axis=1
    )
    
    st.dataframe(table_df, use_container_width=True, height=540)
    
    csv_bytes = filtered_df.to_csv(index=False).encode('utf-8')
    st.download_button(
        label=f"📥 Download {selected_freq} Report (CSV)",
        data=csv_bytes,
        file_name=f"expenditure_{selected_freq.lower()}.csv",
        mime="text/csv"
    )

# ----------------- TAB 3: BENCHMARK MODELS & METRICS -----------------
with tab_models:
    st.subheader("Model Benchmark Leaderboard & Drift Status")
    
    c1, c2 = st.columns([3, 1])
    with c1:
        st.markdown("**Cross-Validation Metrics across 7 Historical Folds (Trained till 31-03-2025)**")
        lb = data['Leaderboard'].copy()
        st.dataframe(lb, use_container_width=True)
        
    with c2:
        st.markdown("**Data Drift & Stability**")
        drift = data['Drift']['Data Drift']
        st.markdown(f"""
        - **PSI**: `{drift['PSI']}`
        - **Status**: `{drift['PSI Status']}`
        - **KS Statistic**: `{drift['KS Statistic']}`
        - **KS p-value**: `{drift['KS p-value']}`
        - **Drift Detected**: `{drift['KS Drift Detected']}`
        """)
        
        st.markdown("**Ensemble Composition**")
        for m, w in data['EnsembleWeights'].items():
            st.markdown(f"- **{m}**: `{w * 100:.1f}%`")

# ----------------- TAB 4: RETRAIN & INGEST NEW DATA -----------------
with tab_retrain:
    st.subheader("🔄 Ingest New Transactions & Trigger Model Retraining")
    st.markdown("""
    When newly audited daily transactions or financial year-end treasury scrolls arrive, you can retrain the forecasting models 
    to absorb the latest actuals, re-fit the seasonal multiplier profiles, re-weight the ensemble, and project another 10 fiscal years forward.
    """)
    
    col_left, col_right = st.columns([1, 1], gap="large")
    
    with col_left:
        st.markdown("#### 1. Quick In-Dashboard Retraining")
        
        uploaded_file = st.file_uploader(
            "Upload New / Updated Transaction CSV (Optional)",
            type=["csv"],
            help="If no file is uploaded, the existing transaction dataset will be used."
        )
        
        retrain_cutoff = st.date_input(
            "Set Training Cutoff Date:",
            value=pd.to_datetime("2025-03-31"),
            help="All data up to this date will be used to train models. Dates after this will be forecasted and validated."
        )
        
        retrain_horizon = st.slider(
            "Forecast Horizon (Fiscal Years):",
            min_value=1,
            max_value=15,
            value=10,
            help="Number of future fiscal years (April to March) to project forward."
        )
        
        if st.button("🚀 Retrain All Models & Refresh Forecasts", type="primary", use_container_width=True):
            status_box = st.status("Initiating Retraining Pipeline...", expanded=True)
            prog_bar = st.progress(0)
            
            def ui_callback(pct, msg):
                prog_bar.progress(pct)
                status_box.write(f"⚙️ {msg}")
                
            try:
                # Save uploaded file if present
                if uploaded_file is not None:
                    csv_target = "uploaded_new_data.csv"
                    with open(csv_target, "wb") as f:
                        f.write(uploaded_file.getbuffer())
                else:
                    csv_target = "CMN_ACTUAL_EXP_RCPT_TXN_filtered_1.csv"
                    
                ui_callback(20, f"Training models up to {retrain_cutoff.strftime('%d-%m-%Y')}...")
                
                # Execute Pipeline
                run_pipeline(
                    csv_path=csv_target,
                    cutoff_date=retrain_cutoff.strftime('%Y-%m-%d'),
                    horizon_years=retrain_horizon,
                    progress_callback=ui_callback
                )
                
                prog_bar.progress(100)
                status_box.update(label="✅ Retraining Complete! Refreshing Dashboard...", state="complete", expanded=False)
                st.cache_data.clear()
                st.success("Successfully retrained models and regenerated hierarchical forecasts! Reloading dashboard...")
                st.rerun()
            except Exception as e:
                status_box.update(label="❌ Retraining Failed", state="error", expanded=True)
                st.error(f"Error during retraining: {str(e)}")
                
    with col_right:
        st.markdown("#### 2. Automated & Batch CLI Retraining")
        st.markdown("""
        For automated quarterly updates, monthly cron jobs, or batch processing pipelines, you can run the pipeline directly via terminal or PowerShell:
        """)
        
        st.code("""# 1. Standard retraining (using default dataset till 31-03-2025)
python pipeline.py

# 2. Retraining with a newly uploaded dataset and updated cutoff
python pipeline.py --csv "path/to/new_data.csv" --cutoff 2026-03-31 --horizon 10
""", language="powershell")
        
        st.markdown("#### 3. Required Input CSV Schema")
        st.markdown("""
        The input CSV file only requires the following primary columns:
        - `ACCOUNTING_DATE`: Transaction posting date (e.g. `DD-MM-YYYY` or `YYYY-MM-DD`).
        - `NET_EXP` (in Rupees) or `EXP_CRORES` (in ₹ Crores).
        
        Any additional metadata columns (Treasury codes, DDO codes, voucher numbers) will be ignored safely.
        """)
        
        st.markdown("#### 4. What Happens During Retraining?")
        st.markdown("""
        1. **Macroeconomic Baseline**: Recalibrates the long-term compound growth rate ($g$) and damping coefficient.
        2. **Seasonal Decomposition**: Re-fits the 4 Fourier harmonics and March surge factors.
        3. **Machine Learning & Deep Learning**: Retrains the 180 XGBoost trees and PyTorch `DeepDecompNet` neural network.
        4. **Ensemble Optimization**: Solves constrained SLSQP quadratic programming to find the optimal model blend.
        5. **Hierarchical Aggregation**: Computes Daily, Weekly, Monthly, Quarterly (Q1-Q4), Half-Yearly, and Yearly projections.
        6. **Drift Monitoring**: Recalculates Population Stability Index (PSI) and Wasserstein drift distances.
        """)

