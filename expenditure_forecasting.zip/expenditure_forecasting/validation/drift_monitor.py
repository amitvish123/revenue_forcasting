"""
Drift Monitoring Suite:
- Data Drift: Population Stability Index (PSI), Kolmogorov-Smirnov (KS) test, Wasserstein Distance
- Model Drift: Rolling Error Degradation, CUSUM change-point detection
"""
import numpy as np
import pandas as pd
from scipy.stats import ks_2samp, wasserstein_distance

def calculate_psi(expected, actual, num_buckets=10):
    """
    Calculate Population Stability Index (PSI) between expected (reference) and actual distributions.
    Rule of thumb:
      PSI < 0.1: No significant shift (Stable)
      0.1 <= PSI < 0.2: Moderate shift (Warning)
      PSI >= 0.2: Significant drift (Action Required)
    """
    expected = np.asarray(expected, dtype=float)
    actual = np.asarray(actual, dtype=float)
    
    # Remove NaNs
    expected = expected[~np.isnan(expected)]
    actual = actual[~np.isnan(actual)]
    
    if len(expected) == 0 or len(actual) == 0:
        return 0.0, "Stable"

    # Define quantile buckets on expected
    percentiles = np.linspace(0, 100, num_buckets + 1)
    bucket_bounds = np.percentile(expected, percentiles)
    bucket_bounds[0] = -np.inf
    bucket_bounds[-1] = np.inf

    # Bucket counts with small epsilon smoothing
    eps = 1e-4
    expected_counts, _ = np.histogram(expected, bins=bucket_bounds)
    actual_counts, _ = np.histogram(actual, bins=bucket_bounds)

    expected_pct = (expected_counts + eps) / (len(expected) + eps * num_buckets)
    actual_pct = (actual_counts + eps) / (len(actual) + eps * num_buckets)

    psi_val = np.sum((actual_pct - expected_pct) * np.log(actual_pct / expected_pct))
    
    if psi_val < 0.1:
        status = "Stable (No Drift)"
    elif psi_val < 0.2:
        status = "Moderate Shift (Watch)"
    else:
        status = "High Drift (Retrain Recommended)"
        
    return round(float(psi_val), 4), status

def compute_data_drift(reference_data, target_data):
    """
    Compute comprehensive data drift metrics
    """
    ref = np.asarray(reference_data, dtype=float)
    tgt = np.asarray(target_data, dtype=float)
    
    psi_val, psi_status = calculate_psi(ref, tgt)
    
    # KS test
    ks_res = ks_2samp(ref, tgt)
    ks_stat = round(float(ks_res.statistic), 4)
    ks_pvalue = round(float(ks_res.pvalue), 4)
    ks_drift = ks_pvalue < 0.05
    
    # Wasserstein distance
    w_dist = round(float(wasserstein_distance(ref, tgt)), 2)
    
    return {
        "PSI": psi_val,
        "PSI Status": psi_status,
        "KS Statistic": ks_stat,
        "KS p-value": ks_pvalue,
        "KS Drift Detected": ks_drift,
        "Wasserstein Distance (Cr)": w_dist
    }

def compute_model_drift(errors, threshold_std=2.0):
    """
    Detect Model Concept Drift using CUSUM test on prediction residuals.
    Alerts if cumulative sum of errors exceeds threshold.
    """
    errors = np.asarray(errors, dtype=float)
    mean_err = np.mean(errors)
    std_err = np.std(errors) if np.std(errors) > 0 else 1.0
    
    # Normalized errors
    norm_err = (errors - mean_err) / std_err
    
    # Cumulative Sum (CUSUM)
    cusum_pos = np.zeros(len(errors))
    cusum_neg = np.zeros(len(errors))
    
    drift_points = []
    slack = 0.5
    for i in range(1, len(errors)):
        cusum_pos[i] = max(0, cusum_pos[i-1] + norm_err[i] - slack)
        cusum_neg[i] = max(0, cusum_neg[i-1] - norm_err[i] - slack)
        if cusum_pos[i] > threshold_std * 3 or cusum_neg[i] > threshold_std * 3:
            drift_points.append(i)
            
    is_model_drift = len(drift_points) > 0
    return {
        "Model Drift Detected": is_model_drift,
        "Drift Alert Frequency": len(drift_points),
        "Residual Mean (Cr)": round(float(mean_err), 2),
        "Residual Std (Cr)": round(float(std_err), 2)
    }
