"""
Evaluation Metrics Suite for State Expenditure Forecasting
Includes WAPE, RMSE, MAE, R2, Directional F1, Surge F1.
"""
import numpy as np
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score, f1_score

def calculate_wape(y_true, y_pred):
    """
    Weighted Absolute Percentage Error (WAPE)
    Formula: sum(|y_true - y_pred|) / sum(y_true) * 100%
    Avoids division by zero / exploding percentages on low-volume days.
    """
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    sum_true = np.sum(np.abs(y_true))
    if sum_true == 0:
        return 0.0
    return float(np.sum(np.abs(y_true - y_pred)) / sum_true * 100.0)

def calculate_directional_f1(y_true, y_pred):
    """
    Directional Movement F1 Score
    Evaluates whether the direction of change from period t-1 to t is correctly predicted.
    Delta True: (y_true[t] - y_true[t-1]) > 0
    Delta Pred: (y_pred[t] - y_true[t-1]) > 0
    """
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    if len(y_true) < 2:
        return 1.0
    
    true_direction = (y_true[1:] - y_true[:-1]) > 0
    pred_direction = (y_pred[1:] - y_true[:-1]) > 0
    
    return float(f1_score(true_direction, pred_direction, average='weighted', zero_division=0))

def calculate_surge_f1(y_true, y_pred, threshold_percentile=90):
    """
    Surge Detection F1 Score
    Identifies high-expenditure surge events (e.g. 90th percentile spikes like March closing).
    """
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    
    thresh = np.percentile(y_true, threshold_percentile)
    true_surge = y_true >= thresh
    pred_surge = y_pred >= thresh
    
    return float(f1_score(true_surge, pred_surge, average='binary', zero_division=0))

def compute_all_metrics(y_true, y_pred):
    """
    Compute comprehensive metrics dictionary
    """
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    
    wape = calculate_wape(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    dir_f1 = calculate_directional_f1(y_true, y_pred)
    surge_f1 = calculate_surge_f1(y_true, y_pred)
    
    return {
        "WAPE (%)": round(wape, 2),
        "RMSE (Cr)": round(rmse, 2),
        "MAE (Cr)": round(mae, 2),
        "R2 Score": round(r2, 4),
        "Directional F1": round(dir_f1, 4),
        "Surge F1": round(surge_f1, 4)
    }
