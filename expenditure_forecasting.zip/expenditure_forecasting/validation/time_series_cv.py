"""
Time Series Cross-Validation & MLflow Logging Suite
Executes Expanding-Window Rolling Origin Validation across fiscal years.
Evaluates WAPE, RMSE, R2, Directional F1, Surge F1, and audits vulnerabilities.
Logs metrics and parameters into MLflow.
"""
import numpy as np
import pandas as pd
import mlflow
from utils.calendar_utils import get_fiscal_year
from validation.metrics import compute_all_metrics
from validation.vulnerability_audit import audit_model_vulnerabilities
from validation.drift_monitor import compute_data_drift, compute_model_drift

from models.cagr_baseline import DampedCAGRForecaster
from models.statistical_models import StatisticalHarmonicForecaster
from models.gbdt_models import XGBoostForecaster
from models.deep_models import DeepDecompForecaster
from models.ensemble import OptimalWeightedEnsemble

def run_cross_validation(df_daily, date_col='ACCOUNTING_DATE', val_col='EXP_CRORES'):
    """
    Run Expanding Window Cross-Validation across historical fiscal years
    """
    df = df_daily.sort_values(date_col).reset_index(drop=True)
    df['FY'] = df[date_col].apply(get_fiscal_year)
    
    unique_fys = sorted(df['FY'].unique())
    # Exclude partial FY if it has fewer than 50 days (e.g. FY 2026-27 has 10 days)
    fy_counts = df.groupby('FY').size()
    full_fys = [fy for fy in unique_fys if fy_counts[fy] >= 300]
    
    # We create folds starting with 5 full fiscal years
    # Fold 1: Train 0..4, Test 5
    # Fold 2: Train 0..5, Test 6
    # ...
    # Fold K: Train 0..K+3, Test K+4
    min_train_years = 5
    folds = []
    for test_idx in range(min_train_years, len(full_fys)):
        train_fys = full_fys[:test_idx]
        test_fy = full_fys[test_idx]
        folds.append((train_fys, [test_fy]))
        
    print(f"Total CV Folds created: {len(folds)}")
    
    model_classes = {
        "Damped CAGR Baseline": lambda: DampedCAGRForecaster(damping_factor=0.97),
        "Statistical Harmonic": lambda: StatisticalHarmonicForecaster(harmonics=4),
        "XGBoost Regressor": lambda: XGBoostForecaster(n_estimators=150, max_depth=5),
        "DeepDecompNet (PyTorch)": lambda: DeepDecompForecaster(hidden_dim=48, epochs=45)
    }
    
    cv_results = {m: [] for m in model_classes.keys()}
    cv_results["Optimal Weighted Ensemble"] = []
    
    # Setup MLflow experiment
    mlflow.set_experiment("State_Revenue_Expenditure_Forecasting")
    
    fold_audits = []
    
    for fold_num, (train_fys, test_fys) in enumerate(folds, 1):
        print(f"\n--- Running Fold {fold_num}/{len(folds)}: Train {train_fys[0]} to {train_fys[-1]} | Test {test_fys[0]} ---")
        
        train_mask = df['FY'].isin(train_fys)
        test_mask = df['FY'].isin(test_fys)
        
        df_train = df[train_mask].copy()
        df_test = df[test_mask].copy()
        
        y_test = df_test[val_col].values
        test_dates = df_test[date_col].values
        
        # Fit benchmark models
        fitted_models = {}
        val_predictions = {}
        train_metrics_dict = {}
        
        with mlflow.start_run(run_name=f"Fold_{fold_num}"):
            mlflow.log_param("fold_num", fold_num)
            mlflow.log_param("train_start_fy", train_fys[0])
            mlflow.log_param("train_end_fy", train_fys[-1])
            mlflow.log_param("test_fy", test_fys[0])
            
            for name, constructor in model_classes.items():
                model = constructor()
                model.fit(df_train, date_col=date_col, val_col=val_col)
                fitted_models[name] = model
                
                # Predictions on test fold
                y_pred = model.predict_dates(test_dates)
                val_predictions[name] = y_pred
                
                # Metrics
                metrics = compute_all_metrics(y_test, y_pred)
                cv_results[name].append(metrics)
                
                # Train metrics for overfitting audit
                train_pred = model.predict_dates(df_train[date_col].values)
                t_metrics = compute_all_metrics(df_train[val_col].values, train_pred)
                train_metrics_dict[name] = t_metrics
                
                # Log to MLflow
                clean_m_model = name.replace("(", "").replace(")", "").replace(" ", "_")
                for m_name, m_val in metrics.items():
                    clean_metric_name = m_name.replace(" ", "_").replace("(", "").replace(")", "").replace("%", "pct")
                    mlflow.log_metric(f"{clean_m_model}_{clean_metric_name}", m_val)
                    
            # Optimal Ensemble for this fold
            ensemble = OptimalWeightedEnsemble(fitted_models)
            ensemble.optimize_weights(y_test, val_predictions)
            ens_pred = ensemble.predict_dates(test_dates)
            ens_metrics = compute_all_metrics(y_test, ens_pred)
            cv_results["Optimal Weighted Ensemble"].append(ens_metrics)
            
            for m_name, m_val in ens_metrics.items():
                clean_metric_name = m_name.replace(" ", "_").replace("(", "").replace(")", "").replace("%", "pct")
                mlflow.log_metric(f"Ensemble_{clean_metric_name}", m_val)
                
            # Audit vulnerability on ensemble
            ens_train_pred = ensemble.predict_dates(df_train[date_col].values)
            ens_t_metrics = compute_all_metrics(df_train[val_col].values, ens_train_pred)
            audit_res = audit_model_vulnerabilities(ens_t_metrics, ens_metrics, ens_pred)
            fold_audits.append({"Fold": fold_num, "Audit": audit_res})
            
            # Data Drift and Model Drift on test window
            data_drift = compute_data_drift(df_train[val_col].values, y_test)
            model_drift = compute_model_drift(y_test - ens_pred)
            mlflow.log_metric("Data_Drift_PSI", data_drift["PSI"])
            mlflow.log_metric("KS_Statistic", data_drift["KS Statistic"])
            
    # Compute aggregate leaderboard across folds
    leaderboard = []
    for model_name, fold_metric_list in cv_results.items():
        summary = {"Model": model_name}
        for metric_key in ["WAPE (%)", "RMSE (Cr)", "MAE (Cr)", "R2 Score", "Directional F1", "Surge F1"]:
            vals = [fm[metric_key] for fm in fold_metric_list]
            summary[metric_key] = round(float(np.mean(vals)), 2 if "Score" not in metric_key and "F1" not in metric_key else 4)
            summary[f"{metric_key} Std"] = round(float(np.std(vals)), 2 if "Score" not in metric_key and "F1" not in metric_key else 4)
        leaderboard.append(summary)
        
    leaderboard_df = pd.DataFrame(leaderboard).sort_values("WAPE (%)").reset_index(drop=True)
    return leaderboard_df, cv_results, fold_audits
