"""
Calendar and Fiscal Date Utilities for Indian State Finances
Indian Financial Year runs from April 1 to March 31.
"""
import pandas as pd
import numpy as np

def get_fiscal_year(dt):
    """Return fiscal year string, e.g., 'FY 2024-25'"""
    year = dt.year
    month = dt.month
    if month >= 4:
        return f"FY {year}-{str(year+1)[-2:]}"
    else:
        return f"FY {year-1}-{str(year)[-2:]}"

def get_fiscal_year_start(dt):
    """Return the start timestamp of the fiscal year for given date"""
    year = dt.year if dt.month >= 4 else dt.year - 1
    return pd.Timestamp(year=year, month=4, day=1)

def get_fiscal_quarter(dt):
    """Return fiscal quarter string: Q1 (AMJ), Q2 (JAS), Q3 (OND), Q4 (JFM)"""
    m = dt.month
    if 4 <= m <= 6:
        q = "Q1 (Apr-Jun)"
    elif 7 <= m <= 9:
        q = "Q2 (Jul-Sep)"
    elif 10 <= m <= 12:
        q = "Q3 (Oct-Dec)"
    else:
        q = "Q4 (Jan-Mar)"
    fy = get_fiscal_year(dt)
    return f"{fy} {q}"

def get_fiscal_quarter_short(dt):
    """Return Q1, Q2, Q3, Q4"""
    m = dt.month
    if 4 <= m <= 6:
        return "Q1"
    elif 7 <= m <= 9:
        return "Q2"
    elif 10 <= m <= 12:
        return "Q3"
    else:
        return "Q4"

def get_fiscal_half(dt):
    """Return fiscal half year string: H1 (Apr-Sep) or H2 (Oct-Mar)"""
    m = dt.month
    h = "H1 (Apr-Sep)" if 4 <= m <= 9 else "H2 (Oct-Mar)"
    fy = get_fiscal_year(dt)
    return f"{fy} {h}"

def get_fiscal_half_short(dt):
    """Return H1 or H2"""
    return "H1" if 4 <= dt.month <= 9 else "H2"

def get_fiscal_month_index(dt):
    """Return 1 for April, 2 for May, ..., 12 for March"""
    return (dt.month - 4) % 12 + 1

def add_calendar_features(df, date_col='ACCOUNTING_DATE'):
    """
    Enrich dataframe with detailed calendar and fiscal features.
    """
    d = df[date_col]
    feat = pd.DataFrame(index=df.index)
    
    feat['year'] = d.dt.year
    feat['month'] = d.dt.month
    feat['day'] = d.dt.day
    feat['dayofweek'] = d.dt.dayofweek
    feat['dayofyear'] = d.dt.dayofyear
    feat['is_weekend'] = (d.dt.dayofweek >= 5).astype(int)
    feat['is_month_start'] = d.dt.is_month_start.astype(int)
    feat['is_month_end'] = d.dt.is_month_end.astype(int)
    
    # Fiscal features
    feat['fiscal_year'] = d.apply(get_fiscal_year)
    feat['fiscal_quarter'] = d.apply(get_fiscal_quarter_short)
    feat['fiscal_half'] = d.apply(get_fiscal_half_short)
    feat['fiscal_month'] = d.apply(get_fiscal_month_index)
    
    # Critical institutional drivers for Indian State Finance
    feat['is_march'] = (d.dt.month == 3).astype(int)
    feat['is_march_end'] = ((d.dt.month == 3) & (d.dt.day >= 25)).astype(int)
    feat['is_march_31'] = ((d.dt.month == 3) & (d.dt.day == 31)).astype(int)
    feat['is_budget_rush'] = ((d.dt.month == 3) & (d.dt.day >= 20)).astype(int)
    feat['is_q4'] = (feat['fiscal_quarter'] == 'Q4').astype(int)
    
    # Cyclic calendar encodings
    feat['month_sin'] = np.sin(2 * np.pi * d.dt.month / 12)
    feat['month_cos'] = np.cos(2 * np.pi * d.dt.month / 12)
    feat['dayofweek_sin'] = np.sin(2 * np.pi * d.dt.dayofweek / 7)
    feat['dayofweek_cos'] = np.cos(2 * np.pi * d.dt.dayofweek / 7)
    feat['dayofyear_sin'] = np.sin(2 * np.pi * d.dt.dayofyear / 365.25)
    feat['dayofyear_cos'] = np.cos(2 * np.pi * d.dt.dayofyear / 365.25)
    
    return pd.concat([df, feat], axis=1)
