"""
Aggregation Engine
Aggregates daily time series forecasts and actuals into:
- Daily
- Weekly
- Monthly
- Quarterly (Fiscal: Q1 Apr-Jun, Q2 Jul-Sep, Q3 Oct-Dec, Q4 Jan-Mar)
- Half-Yearly (Fiscal: H1 Apr-Sep, H2 Oct-Mar)
- Yearly (Fiscal Year: FY Apr 1 - Mar 31)

Ensures fiscal periods are complete so partial/incomplete periods do not create false cliff drops.
"""
import pandas as pd
import numpy as np
from utils.calendar_utils import (
    get_fiscal_year,
    get_fiscal_quarter,
    get_fiscal_half
)

def aggregate_time_series(df, freq="Monthly", date_col="ACCOUNTING_DATE", val_cols=None):
    if val_cols is None:
        val_cols = [c for c in df.columns if c != date_col]
        
    df = df.copy()
    df[date_col] = pd.to_datetime(df[date_col])
    df = df.sort_values(date_col).reset_index(drop=True)
    
    if freq == "Daily":
        res = df[[date_col] + val_cols].copy()
        res['PERIOD_LABEL'] = res[date_col].dt.strftime('%d-%m-%Y')
        return res
        
    elif freq == "Weekly":
        df['WEEK_START'] = df[date_col].dt.to_period('W').apply(lambda r: r.start_time)
        grouped = df.groupby('WEEK_START')[val_cols].sum().reset_index()
        grouped.rename(columns={'WEEK_START': date_col}, inplace=True)
        grouped['PERIOD_LABEL'] = grouped[date_col].dt.strftime('Week of %d-%b-%Y')
        return grouped
        
    elif freq == "Monthly":
        df['MONTH_START'] = df[date_col].dt.to_period('M').apply(lambda r: r.start_time)
        grouped = df.groupby('MONTH_START')[val_cols].sum().reset_index()
        grouped.rename(columns={'MONTH_START': date_col}, inplace=True)
        grouped['PERIOD_LABEL'] = grouped[date_col].dt.strftime('%b %Y')
        return grouped
        
    elif freq == "Quarterly":
        df['FQ_LABEL'] = df[date_col].apply(get_fiscal_quarter)
        actual_counts = df[df['ACTUAL'] > 0].groupby('FQ_LABEL')[date_col].count()
        grouped = df.groupby('FQ_LABEL')[val_cols].sum().reset_index()
        
        for i, row in grouped.iterrows():
            lbl = row['FQ_LABEL']
            if actual_counts.get(lbl, 0) < 60 and 'ACTUAL' in grouped.columns:
                grouped.at[i, 'ACTUAL'] = 0.0
                
        order_df = df.groupby('FQ_LABEL')[date_col].min().reset_index()
        merged = pd.merge(grouped, order_df, on='FQ_LABEL').sort_values(date_col).reset_index(drop=True)
        merged.rename(columns={'FQ_LABEL': 'PERIOD_LABEL'}, inplace=True)
        return merged
        
    elif freq == "Half-Yearly":
        df['FH_LABEL'] = df[date_col].apply(get_fiscal_half)
        actual_counts = df[df['ACTUAL'] > 0].groupby('FH_LABEL')[date_col].count()
        grouped = df.groupby('FH_LABEL')[val_cols].sum().reset_index()
        
        for i, row in grouped.iterrows():
            lbl = row['FH_LABEL']
            if actual_counts.get(lbl, 0) < 130 and 'ACTUAL' in grouped.columns:
                grouped.at[i, 'ACTUAL'] = 0.0
                
        order_df = df.groupby('FH_LABEL')[date_col].min().reset_index()
        merged = pd.merge(grouped, order_df, on='FH_LABEL').sort_values(date_col).reset_index(drop=True)
        merged.rename(columns={'FH_LABEL': 'PERIOD_LABEL'}, inplace=True)
        return merged
        
    elif freq == "Yearly":
        df['FY_LABEL'] = df[date_col].apply(get_fiscal_year)
        actual_counts = df[df['ACTUAL'] > 0].groupby('FY_LABEL')[date_col].count()
        grouped = df.groupby('FY_LABEL')[val_cols].sum().reset_index()
        
        for i, row in grouped.iterrows():
            lbl = row['FY_LABEL']
            if actual_counts.get(lbl, 0) < 300 and 'ACTUAL' in grouped.columns:
                grouped.at[i, 'ACTUAL'] = 0.0
                
        order_df = df.groupby('FY_LABEL')[date_col].min().reset_index()
        merged = pd.merge(grouped, order_df, on='FY_LABEL').sort_values(date_col).reset_index(drop=True)
        merged.rename(columns={'FY_LABEL': 'PERIOD_LABEL'}, inplace=True)
        
        merged = merged[(merged['ACTUAL'] > 0) | (merged['FORECAST'] > 0)].reset_index(drop=True)
        return merged
        
    else:
        raise ValueError(f"Unknown frequency: {freq}")
