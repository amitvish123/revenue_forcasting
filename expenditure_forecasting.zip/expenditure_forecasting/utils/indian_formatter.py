"""
Indian Currency and Number Formatting Utilities
Formats numbers into Indian numbering system (Lakhs, Crores) with appropriate commas and symbols.
Example: 12345678.50 -> "₹1,23,45,678.50" or in Crores: "₹1.23 Cr"
"""
import math

def format_indian_currency(val, decimals=2, unit="Cr", include_symbol=True):
    """
    Format a value into Indian currency notation.
    If unit == "Cr", input `val` is assumed to be already in Crores (or converted).
    Example:
        val = 12345.67 (in Crores) -> "₹12,345.67 Cr"
        val = 123456789 (raw) -> "₹12,34,56,789.00"
    """
    if val is None or (isinstance(val, float) and (math.isnan(val) or math.isinf(val))):
        return "N/A"
    
    prefix = "₹" if include_symbol else ""
    sign = "-" if val < 0 else ""
    abs_val = abs(val)

    if unit == "Cr":
        # Format the number itself with Indian comma style
        formatted_num = format_indian_number(abs_val, decimals=decimals)
        return f"{sign}{prefix}{formatted_num} Cr"
    else:
        formatted_num = format_indian_number(abs_val, decimals=decimals)
        return f"{sign}{prefix}{formatted_num}"

def format_indian_number(number, decimals=2):
    """
    Format a raw number in the Indian numbering style:
    e.g. 123456789.45 -> 12,34,56,789.45
    Last 3 digits grouped together, then subsequent groups of 2 digits.
    """
    if number is None or (isinstance(number, float) and (math.isnan(number) or math.isinf(number))):
        return "N/A"

    # Split integer and decimal parts
    parts = f"{number:.{decimals}f}".split(".")
    int_part = parts[0]
    dec_part = parts[1] if len(parts) > 1 and decimals > 0 else ""

    if len(int_part) <= 3:
        res = int_part
    else:
        # Last 3 digits
        last3 = int_part[-3:]
        remaining = int_part[:-3]
        # Split remaining into groups of 2 from right to left
        groups = []
        while len(remaining) > 2:
            groups.insert(0, remaining[-2:])
            remaining = remaining[:-2]
        if remaining:
            groups.insert(0, remaining)
        res = ",".join(groups) + "," + last3

    if decimals > 0 and dec_part:
        return f"{res}.{dec_part}"
    return res

if __name__ == "__main__":
    test_cases = [123, 1234, 12345, 123456, 1234567, 12345678, 123456789.456]
    for tc in test_cases:
        print(f"{tc} -> {format_indian_number(tc)} -> {format_indian_currency(tc, unit='Cr')}")
