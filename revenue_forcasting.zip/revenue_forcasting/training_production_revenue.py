"""
Production-style train_models.py

Trains Daily, Weekly, Monthly, Quarterly, Half-Yearly and Yearly
models using ONE generic pipeline.

Outputs:
models/
    daily/
    weekly/
    monthly/
    quarterly/
    halfyearly/
    yearly/
"""

import os
import joblib
import numpy as np
import pandas as pd
import xgboost as xgb

from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge

from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import mean_squared_error
import copy

def time_series_cv(model, X, y, n_splits=5):

    n_samples = len(X)

    # Need at least n_splits + 1 samples
    n_splits = min(n_splits, n_samples - 1)

    if n_splits < 2:
        print(f"Only {n_samples} samples available. Skipping cross-validation.")

        model.fit(X, y)
        return model, None, None
        
    tscv = TimeSeriesSplit(n_splits=n_splits)

    fold_scores = []

    best_model = None
    best_rmse = float("inf")

    for fold, (train_idx, valid_idx) in enumerate(tscv.split(X), start=1):

        X_train = X.iloc[train_idx]
        X_valid = X.iloc[valid_idx]

        y_train = y.iloc[train_idx]
        y_valid = y.iloc[valid_idx]

        model.fit(X_train, y_train)

        pred = model.predict(X_valid)

        rmse = np.sqrt(mean_squared_error(y_valid, pred))

        fold_scores.append(rmse)

        print(f"Fold {fold}: RMSE = {rmse:.4f}")

        if rmse < best_rmse:
            best_rmse = rmse
            best_model = copy.deepcopy(model)

    mean_rmse = np.mean(fold_scores)

    print(f"Mean CV RMSE = {mean_rmse:.4f}")

    return best_model, best_rmse, mean_rmse

TRAIN_END_DATE = "2023-12-31"

FEATURE_CONFIG = {
    "daily": {
        "freq":"D",
        "lags":[1,2,3,7,14,30,60,90],
        "rolling":[7,14,30,90]
    },
    "weekly":{
        "freq":"W",
        "lags":[1,2,4,8,12,26,52],
        "rolling":[4,8,12]
    },
    "monthly":{
        "freq":"ME",
        "lags":[1,2,3,6,12,24],
        "rolling":[3,6,12]
    },
    "quarterly":{
        "freq":"QE",
        "lags":[1,2,4,8],
        "rolling":[2,4]
    },
    "halfyearly":{
        "freq":"2QE",
        "lags":[1,2,4],
        "rolling":[2]
    },
    "yearly":{
        "freq":"YE",
        "lags":[1,2,3],
        "rolling":[2]
    }
}


def aggregate(df, freq):
    if freq == "D":
        return df.copy()

    return (
        df.set_index("CREATEDDATE")
          .resample(freq)
          .sum(numeric_only=True)
          .reset_index()
    )

def create_features(df, lags, rolling):

    df = df.copy()

    d = df["CREATEDDATE"]

    df["year"] = d.dt.year
    df["month"] = d.dt.month
    df["quarter"] = d.dt.quarter
    df["day"] = d.dt.day
    df["dayofweek"] = d.dt.dayofweek
    df["dayofyear"] = d.dt.dayofyear
    df["weekofyear"] = d.dt.isocalendar().week.astype(int)

    df["financial_month"] = ((df["month"]-4)%12)+1
    df["financial_quarter"] = ((df["financial_month"]-1)//3)+1

    df["is_month_end"] = d.dt.is_month_end.astype(int)
    df["is_month_start"] = d.dt.is_month_start.astype(int)
    df["is_quarter_end"] = d.dt.is_quarter_end.astype(int)
    df["is_quarter_start"] = d.dt.is_quarter_start.astype(int)
    df["is_year_end"] = d.dt.is_year_end.astype(int)

    df["month_sin"] = np.sin(2*np.pi*df["month"]/12)
    df["month_cos"] = np.cos(2*np.pi*df["month"]/12)

    # Key fiscal surge indicators (March year-end closure)
    df["is_march_end"] = ((df["month"] == 3) & (df["day"] >= 25)).astype(int)
    df["is_march_31"] = ((df["month"] == 3) & (df["day"] == 31)).astype(int)

    for lag in lags:
        df[f"lag_{lag}"] = df["TOTALAMOUNT"].shift(lag)

    shifted = df["TOTALAMOUNT"].shift(1)

    for w in rolling:
        df[f"rolling_mean_{w}"] = shifted.rolling(w).mean()
        df[f"rolling_std_{w}"] = shifted.rolling(w).std()

    # Leak-free differences computed strictly from shifted past observations
    df["diff_1"] = shifted.diff()
    df["pct_change_1"] = shifted.pct_change()

    df = df.replace([np.inf,-np.inf],np.nan)
    df = df.dropna().reset_index(drop=True)

    return df


def train_frequency(name, config):

    print(f"\nTraining {name.upper()}")

    df = pd.read_csv(r"C:\Users\Admin\Desktop\revenue_forcasting\revenue_data\daily_revenue.csv")
    df = df[(df["CREATEDDATE"] >= "2015-01-01") & (df["CREATEDDATE"] <= TRAIN_END_DATE)].copy()

    df["CREATEDDATE"] = pd.to_datetime(df["CREATEDDATE"])

    df = aggregate(df, config["freq"])
   
    df = create_features(
        df,
        config["lags"],
        config["rolling"]
    )

    FEATURES = [
        c for c in df.columns
        if c not in [
            "CREATEDDATE",
            "TOTALAMOUNT"
        ]
    ]

    X = df[FEATURES]

    y = df["TOTALAMOUNT"]

    # shift = max(0,-y.min()+1)

    y = np.log1p(y)

    xgb_model = xgb.XGBRegressor(
        objective="reg:squarederror",
        max_depth=2,
        learning_rate=0.14,
        n_estimators=500,
        subsample=0.7,
        colsample_bytree=0.7,
        reg_alpha=5,
        reg_lambda=10,
        min_child_weight=5,
        random_state=42
    )

    ridge_model = Pipeline([
        ("imputer",SimpleImputer()),
        ("ridge",Ridge(alpha=10))
    ])

    print("\nCross-validating XGBoost...")
    best_xgb_model, best_xgb_rmse, xgb_mean_rmse = time_series_cv(
        xgb_model, X, y
    )

    print("\nCross-validating Ridge...")
    best_ridge_model, best_ridge_rmse, ridge_mean_rmse = time_series_cv(
        ridge_model, X, y
    )
    # xgb_model.fit(X,y)
    # ridge_model.fit(X,y)

    outdir = os.path.join("models",name)

    os.makedirs(outdir,exist_ok=True)

    joblib.dump(
        best_xgb_model,
        os.path.join(outdir, "xgb.pkl")
    )

    joblib.dump(
        best_ridge_model,
        os.path.join(outdir, "ridge.pkl")
    )

    joblib.dump(
        {
            "features":FEATURES,
            "frequency":config["freq"],
            "lags":config["lags"],
            "rolling":config["rolling"],
            "xgb_best_rmse": best_xgb_rmse,
            "xgb_mean_cv_rmse": xgb_mean_rmse,
            "ridge_best_rmse": best_ridge_rmse,
            "ridge_mean_cv_rmse": ridge_mean_rmse
        },
        os.path.join(outdir,"metadata.pkl")
    )

    print("Saved ->", outdir)


def main():

    for name, cfg in FEATURE_CONFIG.items():
        train_frequency(name, cfg)

    print("\nAll models generated successfully.")


if __name__ == "__main__":
    main()