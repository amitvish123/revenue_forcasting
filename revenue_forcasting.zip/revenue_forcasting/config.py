# config.py

XGB_CONFIG = {
    "objective": "reg:squarederror",
    "max_depth": 1,
    "learning_rate": 0.05,
    "n_estimators": 200,
    "subsample": 0.7,
    "colsample_bytree": 0.7,
    "reg_alpha": 5.0,
    "reg_lambda": 10.0,
    "min_child_weight": 5,
    "random_state": 42
}

RIDGE_CONFIG = {
    "alpha": 10.0
}

ENSEMBLE_CONFIG = {
    "xgb_weight": 0.5,
    "ridge_weight": 0.5
}

# Major Heads Configurations
MAJOR_HEADS_CONFIG = {
    "TRAIN_START_DATE": "2015-01-01",
    "TRAIN_END_DATE": "2023-12-31",
    "LAGE_CONFIG": [1, 2, 3, 7, 14, 30, 60, 90],
    "ROLLING_CONFIG": [7, 14, 30, 90],
    
    # Thresholds
    "DENSE_THRESHOLD": 0.15,
    "DENSE_MIN_ACTIVE": 30,
    "SPARSE_THRESHOLD": 0.015,
    "SPARSE_MIN_ACTIVE": 10,

    # Dense Model Parameters
    "DENSE_XGB_PARAMS": {
        "objective": "reg:squarederror",
        "max_depth": 2,
        "learning_rate": 0.1,
        "n_estimators": 300,
        "random_state": 42
    },
    "DENSE_RIDGE_PARAMS": {
        "alpha": 10.0
    },
    "DENSE_ENSEMBLE_WEIGHTS": {
        "xgb_weight": 0.4,
        "ridge_weight": 0.6
    },

    # Sparse Model Parameters
    "SPARSE_RF_PARAMS": {
        "n_estimators": 100,
        "max_depth": 4,
        "random_state": 42
    },
    "SPARSE_XGB_PARAMS": {
        "objective": "reg:squarederror",
        "max_depth": 3,
        "learning_rate": 0.1,
        "n_estimators": 150,
        "random_state": 42
    },
    "SPARSE_RIDGE_PARAMS": {
        "alpha": 10.0
    }
}