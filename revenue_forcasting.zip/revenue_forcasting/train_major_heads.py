import os
import glob
import joblib
import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import mean_squared_error
import copy

from config import MAJOR_HEADS_CONFIG

# Configs
TRAIN_START_DATE = MAJOR_HEADS_CONFIG["TRAIN_START_DATE"]
TRAIN_END_DATE = MAJOR_HEADS_CONFIG["TRAIN_END_DATE"]

LAGE_CONFIG = MAJOR_HEADS_CONFIG["LAGE_CONFIG"]
ROLLING_CONFIG = MAJOR_HEADS_CONFIG["ROLLING_CONFIG"]

class TwoStageModel:
    def __init__(self, classifier, regressor):
        self.classifier = classifier
        self.regressor = regressor
        
    def fit(self, X, y):
        # y is raw amounts (not log-transformed yet)
        y_binary = (y > 0).astype(int)
        self.classifier.fit(X, y_binary)
        
        # Only fit regressor on non-zero targets
        mask = y > 0
        if mask.sum() > 0:
            y_nonzero_log = np.log1p(y[mask])
            self.regressor.fit(X[mask], y_nonzero_log)
        
    def predict(self, X):
        # Predict probability of occurrence
        prob = self.classifier.predict_proba(X)[:, 1]
        # Predict amount given occurrence
        pred_log = self.regressor.predict(X)
        # Clip to prevent exponential overflow to infinity
        pred_log = np.clip(pred_log, None, 50.0)
        pred_amount = np.expm1(pred_log)
        # Final prediction is probability * expected amount
        return prob * pred_amount

class RareModel:
    def __init__(self):
        self.p = 0.0
        self.mean_val = 0.0
        self.monthly_p = {}
        self.monthly_mean = {}
        
    def fit(self, X, y):
        n_days = len(y)
        n_active = (y > 0).sum()
        self.p = n_active / n_days if n_days > 0 else 0.0
        self.mean_val = y[y > 0].mean() if n_active > 0 else 0.0
        
        # Calculate monthly probabilities and means if X has CREATEDDATE
        if X is not None and "CREATEDDATE" in X.columns:
            df = X.copy()
            df["TOTALAMOUNT"] = y
            df["month"] = df["CREATEDDATE"].dt.month
            
            for m in range(1, 13):
                m_df = df[df["month"] == m]
                m_days = len(m_df)
                m_active = (m_df["TOTALAMOUNT"] > 0).sum()
                
                p = m_active / m_days if m_days > 0 else 0.0
                mean_val = m_df[m_df["TOTALAMOUNT"] > 0]["TOTALAMOUNT"].mean() if m_active > 0 else 0.0
                
                self.monthly_p[m] = p
                self.monthly_mean[m] = mean_val
        
    def predict(self, X):
        if not hasattr(self, "monthly_p") or not self.monthly_p or X is None or "month" not in X.columns:
            return np.full(len(X) if X is not None else 1, self.p * self.mean_val)
            
        preds = []
        for m in X["month"]:
            p = self.monthly_p.get(m, 0.0)
            mean_val = self.monthly_mean.get(m, 0.0)
            preds.append(p * mean_val)
        return np.array(preds)

class DenseEnsembleModel:
    def __init__(self, xgb_model, ridge_model, xgb_weight=0.5, ridge_weight=0.5):
        self.xgb_model = xgb_model
        self.ridge_model = ridge_model
        self.xgb_weight = xgb_weight
        self.ridge_weight = ridge_weight
        
    def fit(self, X, y):
        y_log = np.log1p(y)
        self.xgb_model.fit(X, y_log)
        self.ridge_model.fit(X, y_log)
        
    def predict(self, X):
        xgb_pred = np.expm1(np.clip(self.xgb_model.predict(X), None, 50.0))
        ridge_pred = np.expm1(np.clip(self.ridge_model.predict(X), None, 50.0))
        # Ensure non-negative predictions
        xgb_pred = np.clip(xgb_pred, 0, None)
        ridge_pred = np.clip(ridge_pred, 0, None)
        return self.xgb_weight * xgb_pred + self.ridge_weight * ridge_pred

def time_series_cv(model, X, y, n_splits=5):
    n_samples = len(X)
    n_splits = min(n_splits, n_samples - 1)
    if n_splits < 2:
        print(f"Only {n_samples} samples available. Skipping cross-validation.")
        model.fit(X, y)
        return model, None, None
        
    tscv = TimeSeriesSplit(n_splits=n_splits)
    fold_scores = []
    best_model = None
    best_rmse = float("inf")

    for fold, (train_idx, valid_idx) in enumerate(tscv.split(X), start=1):
        X_train = X.iloc[train_idx]
        X_valid = X.iloc[valid_idx]
        y_train = y.iloc[train_idx]
        y_valid = y.iloc[valid_idx]

        model.fit(X_train, y_train)
        pred = model.predict(X_valid)
        rmse = np.sqrt(mean_squared_error(y_valid, pred))
        fold_scores.append(rmse)
        print(f"Fold {fold}: RMSE = {rmse:.4f}")

        if rmse < best_rmse:
            best_rmse = rmse
            best_model = copy.deepcopy(model)

    mean_rmse = np.mean(fold_scores)
    print(f"Mean CV RMSE = {mean_rmse:.4f}")
    return best_model, best_rmse, mean_rmse

def create_features(df, lags, rolling):
    df = df.copy()
    d = df["CREATEDDATE"]
    
    df["year"] = d.dt.year
    df["month"] = d.dt.month
    df["quarter"] = d.dt.quarter
    df["day"] = d.dt.day
    df["dayofweek"] = d.dt.dayofweek
    df["dayofyear"] = d.dt.dayofyear
    df["weekofyear"] = d.dt.isocalendar().week.astype(int)
    
    df["financial_month"] = ((df["month"] - 4) % 12) + 1
    df["financial_quarter"] = ((df["financial_month"] - 1) // 3) + 1
    
    df["is_month_end"] = d.dt.is_month_end.astype(int)
    df["is_month_start"] = d.dt.is_month_start.astype(int)
    df["is_quarter_end"] = d.dt.is_quarter_end.astype(int)
    df["is_quarter_start"] = d.dt.is_quarter_start.astype(int)
    df["is_year_end"] = d.dt.is_year_end.astype(int)
    
    df["month_sin"] = np.sin(2 * np.pi * df["month"] / 12)
    df["month_cos"] = np.cos(2 * np.pi * df["month"] / 12)
    
    for lag in lags:
        df[f"lag_{lag}"] = df["TOTALAMOUNT"].shift(lag)
        
    shifted = df["TOTALAMOUNT"].shift(1)
    for w in rolling:
        df[f"rolling_mean_{w}"] = shifted.rolling(w).mean()
        df[f"rolling_std_{w}"] = shifted.rolling(w).std()
        
    df["diff_1"] = df["TOTALAMOUNT"].diff()
    df["pct_change_1"] = df["TOTALAMOUNT"].pct_change()
    
    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.dropna().reset_index(drop=True)
    return df

def train_major_head(filepath):
    filename = os.path.basename(filepath)
    # Extract major head identifier from name e.g. daily_mh_1054_revenue.csv -> 1054
    mh = filename.split("_")[2]
    
    print(f"\nProcessing Major Head: {mh}")
    raw_df = pd.read_csv(filepath)
    if raw_df.empty:
        print(f"Skipping {mh} (empty file)")
        return
        
    # Rename columns to match main forecasting pipeline
    raw_df = raw_df.rename(columns={"TXN_DATE": "CREATEDDATE", "TOTAL_REVENUE": "TOTALAMOUNT"})
    raw_df["CREATEDDATE"] = pd.to_datetime(raw_df["CREATEDDATE"])
    
    # Sort and aggregate duplicates on the same date
    raw_df = raw_df.groupby("CREATEDDATE")["TOTALAMOUNT"].sum().reset_index()
    raw_df = raw_df.sort_values("CREATEDDATE").reset_index(drop=True)
    
    # Fill daily sequence
    min_date = raw_df["CREATEDDATE"].min()
    # Align to a reasonable global start date if possible, but keep local min if it's later
    start_date = max(min_date, pd.to_datetime(TRAIN_START_DATE))
    end_date = pd.to_datetime(TRAIN_END_DATE)
    
    if start_date >= end_date:
        start_date = min_date
        
    full_idx = pd.date_range(start=start_date, end=end_date, freq="D")
    df_daily = raw_df.set_index("CREATEDDATE").reindex(full_idx, fill_value=0).reset_index()
    df_daily = df_daily.rename(columns={"index": "CREATEDDATE"})
    
    n_days = len(df_daily)
    n_active = (df_daily["TOTALAMOUNT"] > 0).sum()
    density = n_active / n_days if n_days > 0 else 0
    
    print(f"Total days: {n_days}, Active days: {n_active}, Density: {density:.4f}")
    
    # Categorize model type
    model_type = "rare"
    dense_th = MAJOR_HEADS_CONFIG["DENSE_THRESHOLD"]
    dense_ma = MAJOR_HEADS_CONFIG["DENSE_MIN_ACTIVE"]
    sparse_th = MAJOR_HEADS_CONFIG["SPARSE_THRESHOLD"]
    sparse_ma = MAJOR_HEADS_CONFIG["SPARSE_MIN_ACTIVE"]
    
    if density > dense_th and n_active >= dense_ma:
        model_type = "dense"
    elif density >= sparse_th and n_active >= sparse_ma:
        model_type = "sparse"
        
    print(f"Category: {model_type.upper()}")
    
    # Feature extraction
    df_feat = create_features(df_daily, LAGE_CONFIG, ROLLING_CONFIG)
    if df_feat.empty:
        print(f"No features could be generated (too few rows). Forcing Rare baseline.")
        model_type = "rare"
        df_feat = df_daily.copy() # fallback
        
    FEATURES = [c for c in df_feat.columns if c not in ["CREATEDDATE", "TOTALAMOUNT"]]
    
    outdir = os.path.join("models", "major_heads", mh)
    os.makedirs(outdir, exist_ok=True)
    
    if model_type == "rare":
        model = RareModel()
        model.fit(df_daily, df_daily["TOTALAMOUNT"])
        joblib.dump(model, os.path.join(outdir, "model.pkl"))
        metadata = {
            "model_type": "rare",
            "features": [],
            "lags": [],
            "rolling": [],
            "density": density,
            "n_active": int(n_active),
            "n_days": int(n_days)
        }
        joblib.dump(metadata, os.path.join(outdir, "metadata.pkl"))
        print(f"Saved RareModel -> {outdir}")
        return
        
    X = df_feat[FEATURES]
    y = df_feat["TOTALAMOUNT"]
    
    best_name = None
    best_mean_cv_rmse = None
    best_fold_rmse = None
    
    if model_type == "dense":
        y_log = np.log1p(y)
        xgb_params = MAJOR_HEADS_CONFIG["DENSE_XGB_PARAMS"]
        ridge_params = MAJOR_HEADS_CONFIG["DENSE_RIDGE_PARAMS"]
        weights = MAJOR_HEADS_CONFIG["DENSE_ENSEMBLE_WEIGHTS"]
        
        xgb_model = xgb.XGBRegressor(**xgb_params)
        ridge_model = Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("ridge", Ridge(**ridge_params))
        ])
        
        print("\nCross-validating XGBoost...")
        best_xgb_model, best_xgb_rmse, xgb_mean_rmse = time_series_cv(xgb_model, X, y_log)
        print("\nCross-validating Ridge...")
        best_ridge_model, best_ridge_rmse, ridge_mean_rmse = time_series_cv(ridge_model, X, y_log)
        
        if xgb_mean_rmse is not None and ridge_mean_rmse is not None:
            if xgb_mean_rmse <= ridge_mean_rmse:
                print(f"Selected XGBoost (Mean CV RMSE: {xgb_mean_rmse:.4f})")
                model = DenseEnsembleModel(best_xgb_model, ridge_model, xgb_weight=1.0, ridge_weight=0.0)
                model.ridge_model.fit(X, y_log)
                best_name = "xgb"
                best_mean_cv_rmse = xgb_mean_rmse
                best_fold_rmse = best_xgb_rmse
            else:
                print(f"Selected Ridge (Mean CV RMSE: {ridge_mean_rmse:.4f})")
                model = DenseEnsembleModel(xgb_model, best_ridge_model, xgb_weight=0.0, ridge_weight=1.0)
                model.xgb_model.fit(X, y_log)
                best_name = "ridge"
                best_mean_cv_rmse = ridge_mean_rmse
                best_fold_rmse = best_ridge_rmse
        else:
            xgb_model.fit(X, y_log)
            ridge_model.fit(X, y_log)
            model = DenseEnsembleModel(xgb_model, ridge_model, **weights)
            best_name = "ensemble"
            best_mean_cv_rmse = None
            best_fold_rmse = None
            
    elif model_type == "sparse":
        clf_params = MAJOR_HEADS_CONFIG["SPARSE_RF_PARAMS"]
        xgb_params = MAJOR_HEADS_CONFIG["SPARSE_XGB_PARAMS"]
        ridge_params = MAJOR_HEADS_CONFIG["SPARSE_RIDGE_PARAMS"]
        
        clf = RandomForestClassifier(**clf_params)
        reg_xgb = Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("xgb", xgb.XGBRegressor(**xgb_params))
        ])
        reg_ridge = Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("ridge", Ridge(**ridge_params))
        ])
        
        model_xgb = TwoStageModel(clf, reg_xgb)
        model_ridge = TwoStageModel(clf, reg_ridge)
        
        print("\nCross-validating TwoStage XGBoost...")
        best_ts_xgb, best_ts_xgb_rmse, ts_xgb_mean_rmse = time_series_cv(model_xgb, X, y)
        print("\nCross-validating TwoStage Ridge...")
        best_ts_ridge, best_ts_ridge_rmse, ts_ridge_mean_rmse = time_series_cv(model_ridge, X, y)
        
        if ts_xgb_mean_rmse is not None and ts_ridge_mean_rmse is not None:
            if ts_xgb_mean_rmse <= ts_ridge_mean_rmse:
                print(f"Selected TwoStage XGBoost (Mean CV RMSE: {ts_xgb_mean_rmse:.4f})")
                model = best_ts_xgb
                best_name = "two_stage_xgb"
                best_mean_cv_rmse = ts_xgb_mean_rmse
                best_fold_rmse = best_ts_xgb_rmse
            else:
                print(f"Selected TwoStage Ridge (Mean CV RMSE: {ts_ridge_mean_rmse:.4f})")
                model = best_ts_ridge
                best_name = "two_stage_ridge"
                best_mean_cv_rmse = ts_ridge_mean_rmse
                best_fold_rmse = best_ts_ridge_rmse
        else:
            model = model_xgb
            model.fit(X, y)
            best_name = "two_stage_xgb"
            best_mean_cv_rmse = None
            best_fold_rmse = None
        
    # Save model and metadata
    joblib.dump(model, os.path.join(outdir, "model.pkl"))
    metadata = {
        "model_type": model_type,
        "best_model_name": best_name,
        "mean_cv_rmse": best_mean_cv_rmse if best_mean_cv_rmse is not None else None,
        "best_fold_rmse": best_fold_rmse if best_fold_rmse is not None else None,
        "features": FEATURES,
        "lags": LAGE_CONFIG,
        "rolling": ROLLING_CONFIG,
        "density": density,
        "n_active": int(n_active),
        "n_days": int(n_days)
    }
    joblib.dump(metadata, os.path.join(outdir, "metadata.pkl"))
    print(f"Saved model and metadata -> {outdir}")

def main():
    data_dir = "revenue_data"
    pattern = os.path.join(data_dir, "daily_mh_*_revenue.csv")
    filepaths = glob.glob(pattern)
    print(f"Found {len(filepaths)} Major Head CSV files.")
    
    for fp in filepaths:
        try:
            train_major_head(fp)
        except Exception as e:
            print(f"Error training model for {fp}: {e}")
            
    print("\nTraining completed for all major heads.")

if __name__ == "__main__":
    main()
