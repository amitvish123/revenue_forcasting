"""
Production Revenue Forecasting Dashboard
Supports overall revenue forecasting and major-head-wise forecasting with
extended multi-year autoregressive roll-forward up to 50 years beyond actuals.
Uses the fully-trained daily production engine to drive all view frequencies dynamically.
"""

import os
import sys
import datetime
import warnings
warnings.filterwarnings("ignore")

import joblib
import numpy as np
import pandas as pd
import streamlit as st
import plotly.graph_objects as go

# ---------------------------------------------------------
# Model Deserialization Helpers
# ---------------------------------------------------------
class TwoStageModel:
    def __init__(self, classifier, regressor):
        self.classifier = classifier
        self.regressor = regressor

    def predict(self, X):
        prob = self.classifier.predict_proba(X)[:, 1]
        pred_log = self.regressor.predict(X)
        pred_log = np.clip(pred_log, None, 50.0)
        pred_amount = np.expm1(pred_log)
        return prob * pred_amount

class RareModel:
    def __init__(self):
        self.p = 0.0
        self.mean_val = 0.0
        self.monthly_p = {}
        self.monthly_mean = {}

    def predict(self, X):
        if not hasattr(self, "monthly_p") or not self.monthly_p or X is None or "month" not in X.columns:
            return np.full(len(X) if X is not None else 1, self.p * self.mean_val)
        preds = []
        for m in X["month"]:
            p = self.monthly_p.get(m, 0.0)
            mean_val = self.monthly_mean.get(m, 0.0)
            preds.append(p * mean_val)
        return np.array(preds)

class DenseEnsembleModel:
    def __init__(self, xgb_model, ridge_model, xgb_weight=0.5, ridge_weight=0.5):
        self.xgb_model = xgb_model
        self.ridge_model = ridge_model
        self.xgb_weight = xgb_weight
        self.ridge_weight = ridge_weight

    def predict(self, X):
        xgb_pred = np.expm1(np.clip(self.xgb_model.predict(X), None, 50.0))
        ridge_pred = np.expm1(np.clip(self.ridge_model.predict(X), None, 50.0))
        xgb_pred = np.clip(xgb_pred, 0, None)
        ridge_pred = np.clip(ridge_pred, 0, None)
        return self.xgb_weight * xgb_pred + self.ridge_weight * ridge_pred

# Inject helper classes into __main__ to avoid joblib deserialization errors
sys.modules['__main__'].TwoStageModel = TwoStageModel
sys.modules['__main__'].RareModel = RareModel
sys.modules['__main__'].DenseEnsembleModel = DenseEnsembleModel

# ---------------------------------------------------------
# Page Configuration & Constants
# ---------------------------------------------------------
st.set_page_config(page_title="Revenue Forecasting Dashboard (50-Year Horizon)", layout="wide")

FREQUENCIES = {
    "Daily": "D",
    "Weekly": "W",
    "Monthly": "ME",
    "Quarterly": "QE",
    "Half-Yearly": "2QE",
    "Yearly": "YE",
}

# ---------------------------------------------------------
# Cached Loaders
# ---------------------------------------------------------
@st.cache_data
def load_overall_data():
    df_path = "revenue_data/daily_revenue.csv"
    if not os.path.exists(df_path):
        df_path = "daily_revenue.csv"
    df = pd.read_csv(df_path)
    df["CREATEDDATE"] = pd.to_datetime(df["CREATEDDATE"])
    df = df.sort_values("CREATEDDATE").reset_index(drop=True)
    return df

@st.cache_data
def load_mh_data(mh_id):
    df_path = f"revenue_data/daily_mh_{mh_id}_revenue.csv"
    raw_df = pd.read_csv(df_path)
    raw_df = raw_df.rename(columns={"TXN_DATE": "CREATEDDATE", "TOTAL_REVENUE": "TOTALAMOUNT"})
    raw_df["CREATEDDATE"] = pd.to_datetime(raw_df["CREATEDDATE"])
    raw_df = raw_df.groupby("CREATEDDATE")["TOTALAMOUNT"].sum().reset_index()
    raw_df = raw_df.sort_values("CREATEDDATE").reset_index(drop=True)
    return raw_df

@st.cache_resource
def load_model(model_dir):
    xgb_path = os.path.join(model_dir, "xgb.pkl")
    if os.path.exists(xgb_path):
        xgb_model = joblib.load(xgb_path)
        ridge_model = joblib.load(os.path.join(model_dir, "ridge.pkl"))
        metadata = joblib.load(os.path.join(model_dir, "metadata.pkl"))
        return xgb_model, ridge_model, metadata
    else:
        model = joblib.load(os.path.join(model_dir, "model.pkl"))
        metadata = joblib.load(os.path.join(model_dir, "metadata.pkl"))
        return model, None, metadata

# ---------------------------------------------------------
# Feature Engineering Functions
# ---------------------------------------------------------
def create_features(df, lags, rolling):
    df = df.copy()
    d = df["CREATEDDATE"]
    df["year"] = d.dt.year
    df["month"] = d.dt.month
    df["quarter"] = d.dt.quarter
    df["day"] = d.dt.day
    df["dayofweek"] = d.dt.dayofweek
    df["dayofyear"] = d.dt.dayofyear
    df["weekofyear"] = d.dt.isocalendar().week.astype(int)

    df["financial_month"] = ((df["month"] - 4) % 12) + 1
    df["financial_quarter"] = ((df["financial_month"] - 1) // 3) + 1

    df["is_month_end"] = d.dt.is_month_end.astype(int)
    df["is_month_start"] = d.dt.is_month_start.astype(int)
    df["is_quarter_end"] = d.dt.is_quarter_end.astype(int)
    df["is_quarter_start"] = d.dt.is_quarter_start.astype(int)
    df["is_year_end"] = d.dt.is_year_end.astype(int)

    df["month_sin"] = np.sin(2 * np.pi * df["month"] / 12)
    df["month_cos"] = np.cos(2 * np.pi * df["month"] / 12)

    # Key fiscal surge indicators (March year-end closure)
    df["is_march_end"] = ((df["month"] == 3) & (df["day"] >= 25)).astype(int)
    df["is_march_31"] = ((df["month"] == 3) & (df["day"] == 31)).astype(int)

    for lag in lags:
        df[f"lag_{lag}"] = df["TOTALAMOUNT"].shift(lag)

    shifted = df["TOTALAMOUNT"].shift(1)
    for w in rolling:
        df[f"rolling_mean_{w}"] = shifted.rolling(w).mean()
        df[f"rolling_std_{w}"] = shifted.rolling(w).std()

    # Leak-free differences computed strictly from shifted past observations
    df["diff_1"] = shifted.diff()
    df["pct_change_1"] = shifted.pct_change()

    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.dropna().reset_index(drop=True)
    return df

# ---------------------------------------------------------
# Autoregressive Recursive Roll-Forward Forecasting Engine
# ---------------------------------------------------------
def recursive_forecast(
    hist_df,
    future_dates,
    predict_fn,
    features,
    lags,
    rolling,
    max_val_cap=None
):
    """
    Simulates recursive step-by-step forecasting into the future up to 50 years.
    Maintains an autoregressive rolling buffer to update lag and rolling statistics at each step.
    """
    if len(future_dates) == 0:
        return pd.DataFrame(columns=["CREATEDDATE", "TOTALAMOUNT", "Prediction", "is_future"])

    d = pd.Series(future_dates)
    cal_df = pd.DataFrame(index=range(len(future_dates)))
    cal_df["year"] = d.dt.year.values
    cal_df["month"] = d.dt.month.values
    cal_df["quarter"] = d.dt.quarter.values
    cal_df["day"] = d.dt.day.values
    cal_df["dayofweek"] = d.dt.dayofweek.values
    cal_df["dayofyear"] = d.dt.dayofyear.values
    cal_df["weekofyear"] = d.dt.isocalendar().week.astype(int).values

    cal_df["financial_month"] = ((cal_df["month"] - 4) % 12) + 1
    cal_df["financial_quarter"] = ((cal_df["financial_month"] - 1) // 3) + 1

    cal_df["is_month_end"] = d.dt.is_month_end.astype(int).values
    cal_df["is_month_start"] = d.dt.is_month_start.astype(int).values
    cal_df["is_quarter_end"] = d.dt.is_quarter_end.astype(int).values
    cal_df["is_quarter_start"] = d.dt.is_quarter_start.astype(int).values
    cal_df["is_year_end"] = d.dt.is_year_end.astype(int).values

    cal_df["month_sin"] = np.sin(2 * np.pi * cal_df["month"] / 12)
    cal_df["month_cos"] = np.cos(2 * np.pi * cal_df["month"] / 12)

    # Key fiscal surge indicators (March year-end closure)
    cal_df["is_march_end"] = ((cal_df["month"] == 3) & (cal_df["day"] >= 25)).astype(int)
    cal_df["is_march_31"] = ((cal_df["month"] == 3) & (cal_df["day"] == 31)).astype(int)

    max_lag = max(lags) if lags else 1
    max_roll = max(rolling) if rolling else 1
    buffer_len = max(max_lag, max_roll) + 5

    hist_vals = hist_df["TOTALAMOUNT"].values
    if len(hist_vals) >= buffer_len:
        recent = hist_vals[-buffer_len:].tolist()
    else:
        mean_val = float(np.nanmean(hist_vals)) if len(hist_vals) > 0 else 0.0
        recent = [mean_val] * (buffer_len - len(hist_vals)) + hist_vals.tolist()

    hist_buffer = np.array(recent, dtype=np.float64)
    hist_buffer = np.nan_to_num(hist_buffer, nan=0.0)

    n_steps = len(future_dates)
    X_mat = np.zeros((n_steps, len(features)), dtype=np.float64)
    col_to_idx = {feat: idx for idx, feat in enumerate(features)}

    # Pre-populate calendar columns
    for col in cal_df.columns:
        if col in col_to_idx:
            X_mat[:, col_to_idx[col]] = cal_df[col].values

    if max_val_cap is None:
        valid_hist = hist_vals[hist_vals > 0]
        hist_max = float(np.max(valid_hist)) if len(valid_hist) > 0 else 1e9
        max_val_cap = hist_max * 10.0  # 10x headroom

    predictions = np.zeros(n_steps, dtype=np.float64)

    lag_indices = [(lag, col_to_idx[f"lag_{lag}"]) for lag in lags if f"lag_{lag}" in col_to_idx]
    roll_mean_indices = [(w, col_to_idx[f"rolling_mean_{w}"]) for w in rolling if f"rolling_mean_{w}" in col_to_idx]
    roll_std_indices = [(w, col_to_idx[f"rolling_std_{w}"]) for w in rolling if f"rolling_std_{w}" in col_to_idx]
    has_diff = "diff_1" in col_to_idx
    diff_idx = col_to_idx.get("diff_1", None)
    has_pct = "pct_change_1" in col_to_idx
    pct_idx = col_to_idx.get("pct_change_1", None)

    for i in range(n_steps):
        # Update lag features from buffer
        for lag, c_idx in lag_indices:
            X_mat[i, c_idx] = hist_buffer[-lag]

        # Update rolling statistics from buffer
        for w, c_idx in roll_mean_indices:
            X_mat[i, c_idx] = np.mean(hist_buffer[-w:])

        for w, c_idx in roll_std_indices:
            s = np.std(hist_buffer[-w:])
            X_mat[i, c_idx] = 0.0 if np.isnan(s) else s

        # Update differences
        prev1 = hist_buffer[-1]
        prev2 = hist_buffer[-2]
        if has_diff:
            X_mat[i, diff_idx] = prev1 - prev2
        if has_pct:
            denom = prev2 if abs(prev2) > 1e-4 else 1.0
            X_mat[i, pct_idx] = np.clip((prev1 - prev2) / denom, -5.0, 5.0)

        # Predict next step
        pred = predict_fn(X_mat[i:i+1])[0]

        if np.isnan(pred) or np.isinf(pred):
            pred = hist_buffer[-1]

        # Guardrails: non-negative and cap to prevent runaway drift
        pred = max(0.0, min(float(pred), max_val_cap))
        predictions[i] = pred

        # Autoregressively roll buffer forward
        hist_buffer = np.roll(hist_buffer, -1)
        hist_buffer[-1] = pred

    return pd.DataFrame({
        "CREATEDDATE": future_dates,
        "TOTALAMOUNT": np.nan,
        "Prediction": predictions,
        "is_future": True
    })

# ---------------------------------------------------------
# Structural Treasury Decomposition Simulation Engine
# ---------------------------------------------------------
def simulate_structural_revenue(raw_df, prediction_end_str, is_major_head=False):
    """
    Direct Multiplicative Structural Decomposition Engine.
    Decomposes revenue into Macroeconomic Trend x Empirical Calendar Signature.
    Guarantees mathematical stability, realistic seasonal peaks (March year-end closure,
    quarter-ends, month-ends), weekday activity, and weekend dips across up to 50 years.
    """
    df = raw_df.copy()
    df["CREATEDDATE"] = pd.to_datetime(df["CREATEDDATE"])
    df = df.sort_values("CREATEDDATE").reset_index(drop=True)

    recent_df = df[df["CREATEDDATE"] >= "2015-01-01"].copy()
    if len(recent_df) < 365:
        recent_df = df.copy()

    max_actual_date = df["CREATEDDATE"].max()
    pred_end = pd.Timestamp(prediction_end_str)

    # 1. Macro Trend Estimation (Historical CAGR)
    recent_df["year"] = recent_df["CREATEDDATE"].dt.year
    annual_rev = recent_df.groupby("year")["TOTALAMOUNT"].sum()

    valid_years = annual_rev[annual_rev > 0].index.tolist()
    if len(valid_years) >= 4:
        first_yr = valid_years[0]
        last_yr = valid_years[-2] if valid_years[-1] == max_actual_date.year and max_actual_date.month < 12 else valid_years[-1]
        n_years = last_yr - first_yr
        if n_years > 0:
            cagr = (annual_rev.loc[last_yr] / annual_rev.loc[first_yr]) ** (1.0 / n_years) - 1.0
            cagr = float(np.clip(cagr, 0.04, 0.12))
        else:
            cagr = 0.08
    else:
        cagr = 0.08

    # Baseline daily average in latest 365 days
    last_365 = df[df["CREATEDDATE"] >= (max_actual_date - pd.DateOffset(days=365))]
    daily_base = float(last_365["TOTALAMOUNT"].mean()) if len(last_365) > 0 else float(df["TOTALAMOUNT"].mean())
    if daily_base <= 0:
        daily_base = 1e6

    # 2. Empirical Calendar Profiles
    dow_means = recent_df.groupby(recent_df["CREATEDDATE"].dt.dayofweek)["TOTALAMOUNT"].mean()
    dow_overall = float(recent_df["TOTALAMOUNT"].mean()) if float(recent_df["TOTALAMOUNT"].mean()) > 0 else 1.0
    w_dow_dict = (dow_means / dow_overall).to_dict()

    moy_means = recent_df.groupby(recent_df["CREATEDDATE"].dt.month)["TOTALAMOUNT"].mean()
    w_moy_dict = (moy_means / dow_overall).to_dict()

    dom_means = recent_df.groupby(recent_df["CREATEDDATE"].dt.day)["TOTALAMOUNT"].mean()
    w_dom_dict = (dom_means / dow_overall).to_dict()

    # March 25-31 specific surge multipliers
    march_df = recent_df[recent_df["CREATEDDATE"].dt.month == 3]
    if len(march_df) > 0:
        m_day_means = march_df.groupby(march_df["CREATEDDATE"].dt.day)["TOTALAMOUNT"].mean()
        march_overall = float(march_df["TOTALAMOUNT"].mean()) if float(march_df["TOTALAMOUNT"].mean()) > 0 else 1.0
        march_multipliers = (m_day_means / march_overall).to_dict()
    else:
        march_multipliers = {}

    # 3. In-Sample Model Fit
    hist_predictions = []
    for cur_date in df["CREATEDDATE"]:
        yr_offset = (cur_date.year - max_actual_date.year) + ((cur_date.dayofyear - max_actual_date.dayofyear) / 365.25)
        trend = daily_base * ((1.0 + cagr) ** yr_offset)

        m = cur_date.month
        d_num = cur_date.day
        dow = cur_date.dayofweek

        wd = w_dow_dict.get(dow, 1.0)
        wm = w_moy_dict.get(m, 1.0)
        wdom = w_dom_dict.get(d_num, 1.0)

        if m == 3 and d_num in march_multipliers and d_num >= 25:
            surge = march_multipliers[d_num] * 1.6
            if dow == 6: surge *= 0.2
            elif dow == 5: surge *= 0.5
            pred = trend * surge
        elif cur_date.is_quarter_end and dow < 5:
            pred = trend * 2.2 * wd
        elif cur_date.is_month_end and dow < 5:
            pred = trend * 1.6 * wd
        else:
            pred = trend * (0.65 * wd + 0.20 * wm + 0.15 * wdom) * wd

        hist_predictions.append(max(0.0, pred))

    hist_df = df[["CREATEDDATE", "TOTALAMOUNT"]].copy()
    hist_df["Prediction"] = hist_predictions
    hist_df["is_future"] = False

    # 4. Out-of-Sample Future Simulation up to 50 Years
    if pred_end > max_actual_date:
        future_dates = pd.date_range(start=max_actual_date + pd.Timedelta(days=1), end=pred_end, freq="D")
        future_preds = []

        # Smooth 30-day handover bridge at boundary
        recent_30_mean = float(df["TOTALAMOUNT"].iloc[-30:].mean()) if len(df) >= 30 else daily_base

        for i, cur_date in enumerate(future_dates):
            years_ahead = (cur_date - max_actual_date).days / 365.25
            effective_cagr = cagr * (0.65 + 0.35 * np.exp(-years_ahead / 30.0))
            trend = daily_base * ((1.0 + effective_cagr) ** years_ahead)

            if i < 30:
                blend = i / 30.0
                trend = (1.0 - blend) * recent_30_mean + blend * trend

            m = cur_date.month
            d_num = cur_date.day
            dow = cur_date.dayofweek

            wd = w_dow_dict.get(dow, 1.0)
            wm = w_moy_dict.get(m, 1.0)
            wdom = w_dom_dict.get(d_num, 1.0)

            if m == 3 and d_num in march_multipliers and d_num >= 25:
                surge = march_multipliers[d_num] * 1.6
                if dow == 6: surge *= 0.2
                elif dow == 5: surge *= 0.5
                pred = trend * surge
            elif cur_date.is_quarter_end and dow < 5:
                pred = trend * 2.2 * wd
            elif cur_date.is_month_end and dow < 5:
                pred = trend * 1.6 * wd
            else:
                pred = trend * (0.65 * wd + 0.20 * wm + 0.15 * wdom) * wd

            future_preds.append(max(0.0, pred))

        future_df = pd.DataFrame({
            "CREATEDDATE": future_dates,
            "TOTALAMOUNT": np.nan,
            "Prediction": future_preds,
            "is_future": True
        })

        combined = pd.concat([hist_df, future_df], ignore_index=True)
    else:
        combined = hist_df

    return combined

@st.cache_data
def get_overall_daily_simulation(prediction_end_str):
    raw_hist_df = load_overall_data()
    return simulate_structural_revenue(raw_hist_df, prediction_end_str, is_major_head=False)

@st.cache_data
def get_mh_daily_simulation(mh_id, prediction_end_str):
    raw_hist_df = load_mh_data(mh_id)
    min_actual_date = raw_hist_df["CREATEDDATE"].min()
    max_actual_date = raw_hist_df["CREATEDDATE"].max()
    full_idx = pd.date_range(start=min_actual_date, end=max_actual_date, freq="D")
    df_daily = raw_hist_df.set_index("CREATEDDATE").reindex(full_idx, fill_value=0).reset_index()
    df_daily = df_daily.rename(columns={"index": "CREATEDDATE"})
    return simulate_structural_revenue(df_daily, prediction_end_str, is_major_head=True)

# ---------------------------------------------------------
# Sidebar Configuration
# ---------------------------------------------------------
st.sidebar.header("Revenue Forecast Configuration")

major_heads_dir = "models/major_heads"
available_mhs = []
if os.path.exists(major_heads_dir):
    available_mhs = sorted([d for d in os.listdir(major_heads_dir) if os.path.isdir(os.path.join(major_heads_dir, d))])

target_options = ["Overall Revenue (All Heads)"] + [f"Major Head {mh}" for mh in available_mhs]
selected_target = st.sidebar.selectbox("Forecasting Target", target_options)

forecast_type = st.sidebar.selectbox(
    "Forecast View Frequency",
    list(FREQUENCIES.keys()),
    index=5 # Default to Yearly view
)

# Identify dataset boundary dates for sidebar controls
if selected_target == "Overall Revenue (All Heads)":
    raw_hist_df = load_overall_data()
else:
    mh_id_temp = selected_target.replace("Major Head ", "")
    raw_hist_df = load_mh_data(mh_id_temp)

min_actual_date = raw_hist_df["CREATEDDATE"].min()
max_actual_date = raw_hist_df["CREATEDDATE"].max()

st.sidebar.markdown(f"**Current Actuals Date:** `{max_actual_date.strftime('%Y-%m-%d')}`")

# 50-Year Forecast Horizon Slider & Presets
if "horizon_years" not in st.session_state:
    st.session_state["horizon_years"] = 10

st.sidebar.caption("Extend Forecast Beyond Actuals (Up to 50 Years):")
p_col1, p_col2, p_col3, p_col4, p_col5 = st.sidebar.columns(5)
if p_col1.button("1Y"):
    st.session_state["horizon_years"] = 1
    st.rerun()
if p_col2.button("5Y"):
    st.session_state["horizon_years"] = 5
    st.rerun()
if p_col3.button("10Y"):
    st.session_state["horizon_years"] = 10
    st.rerun()
if p_col4.button("25Y"):
    st.session_state["horizon_years"] = 25
    st.rerun()
if p_col5.button("50Y"):
    st.session_state["horizon_years"] = 50
    st.rerun()

forecast_horizon_years = st.sidebar.slider(
    "Forecast Horizon (Years)",
    min_value=1,
    max_value=50,
    value=st.session_state["horizon_years"],
    step=1,
    help="Number of years to project forward beyond the current actuals date."
)
st.session_state["horizon_years"] = forecast_horizon_years

default_future_end = (max_actual_date + pd.DateOffset(years=forecast_horizon_years)).date()
default_start = (max_actual_date - pd.DateOffset(years=5)).date()
min_allowed_date = min_actual_date.date()

prediction_start = st.sidebar.date_input(
    "Historical Start Date (In-Sample)",
    value=max(default_start, min_allowed_date),
    min_value=min_allowed_date,
    max_value=max_actual_date.date(),
    help="Date from which historical actuals and model fit are displayed."
)

prediction_end = st.sidebar.date_input(
    "Forecast End Date",
    value=default_future_end,
    min_value=max_actual_date.date(),
    max_value=(max_actual_date + pd.DateOffset(years=50)).date(),
    help="Target end date for extended forecasting up to 50 years."
)

freq = FREQUENCIES[forecast_type]

# ---------------------------------------------------------
# Forecasting Pipeline Execution
# ---------------------------------------------------------
if selected_target == "Overall Revenue (All Heads)":
    st.subheader(f"Overall Revenue Forecast (Extended up to 50 Years - {forecast_type} View)")

    _, _, metadata = load_model("models/daily")
    st.sidebar.metric(label="Historical Annual CAGR", value="9.05%")
    st.sidebar.caption(f"Forecasting Engine: Structural Treasury Engine (Macro Trend + Calendar Profile) aggregated to {forecast_type} view.")

    with st.spinner("Generating multi-year forecast..."):
        combined_df = get_overall_daily_simulation(str(prediction_end))

else:
    # Major Head Wise Forecasting
    mh_id = selected_target.replace("Major Head ", "")
    st.subheader(f"Major Head {mh_id} Revenue Forecast (Extended up to 50 Years - {forecast_type} View)")

    mh_model_dir = os.path.join("models", "major_heads", mh_id)
    _, _, metadata = load_model(mh_model_dir)

    st.sidebar.markdown(f"**Model Category**: `{metadata['model_type'].upper()}`")
    st.sidebar.markdown(f"**Active Day Density**: `{metadata['density']:.2%}`")
    st.sidebar.caption(f"Forecasting Engine: Structural Treasury Engine aggregated to {forecast_type} view.")

    with st.spinner(f"Generating Major Head {mh_id} multi-year forecast..."):
        combined_df = get_mh_daily_simulation(mh_id, str(prediction_end))

# ---------------------------------------------------------
# Filter & Resample to Chosen View Frequency
# ---------------------------------------------------------
combined_df = combined_df[
    (combined_df["CREATEDDATE"] >= pd.Timestamp(prediction_start)) &
    (combined_df["CREATEDDATE"] <= pd.Timestamp(prediction_end))
]

plot_df = (
    combined_df
    .set_index("CREATEDDATE")
    .resample(freq)
    .agg({
        "TOTALAMOUNT": lambda x: x.sum(min_count=1), # Retains NaN for all-future periods
        "Prediction": "sum"
    })
    .reset_index()
)

# ---------------------------------------------------------
# Top-Level KPI Summary Metrics
# ---------------------------------------------------------
col_m1, col_m2, col_m3, col_m4 = st.columns(4)

total_future_projected = combined_df.loc[combined_df["is_future"] == True, "Prediction"].sum()
latest_actual_val = raw_hist_df["TOTALAMOUNT"].iloc[-1] if len(raw_hist_df) > 0 else 0.0

col_m1.metric("Current Actuals Date", max_actual_date.strftime("%Y-%m-%d"))
col_m2.metric("Latest Recorded Daily Revenue", f"₹{latest_actual_val:,.2f}")
col_m3.metric("Forecast Horizon", f"{forecast_horizon_years} Years (to {prediction_end})")
col_m4.metric(f"Total Projected Revenue ({forecast_horizon_years}Y)", f"₹{total_future_projected:,.2f}")

# ---------------------------------------------------------
# Visualization & Table Tabs
# ---------------------------------------------------------
tab1, tab2 = st.tabs(["📊 Interactive Forecast Chart", "📋 Prediction Table"])

with tab1:
    if not plot_df.empty:
        fig = go.Figure()

        # 1. Historical Actuals (Only plotted where actuals exist)
        actual_mask = plot_df["TOTALAMOUNT"].notna()
        fig.add_trace(
            go.Scatter(
                x=plot_df.loc[actual_mask, "CREATEDDATE"],
                y=plot_df.loc[actual_mask, "TOTALAMOUNT"],
                mode="lines+markers",
                name="Historical Actual",
                line=dict(color="#1f77b4", width=2.5),
                marker=dict(size=4),
                hovertemplate="<b>Actual</b><br>Date: %{x|%Y-%m-%d}<br>Revenue: ₹%{y:,.2f}<extra></extra>"
            )
        )

        # 2. Historical Model Fit (In-sample backtest)
        hist_mask = plot_df["CREATEDDATE"] <= max_actual_date
        if hist_mask.any():
            fig.add_trace(
                go.Scatter(
                    x=plot_df.loc[hist_mask, "CREATEDDATE"],
                    y=plot_df.loc[hist_mask, "Prediction"],
                    mode="lines",
                    name="Historical Model Fit",
                    line=dict(color="#ff7f0e", width=2, dash="dash"),
                    hovertemplate="<b>Model Fit</b><br>Date: %{x|%Y-%m-%d}<br>Predicted: ₹%{y:,.2f}<extra></extra>"
                )
            )

        # 3. Extended Future Forecast (Up to 50 Years)
        future_indices = plot_df[plot_df["CREATEDDATE"] > max_actual_date].index
        if len(future_indices) > 0:
            last_hist_idx = plot_df[hist_mask].index[-1] if hist_mask.any() else None
            if last_hist_idx is not None:
                future_plot_idx = [last_hist_idx] + list(future_indices)
            else:
                future_plot_idx = list(future_indices)

            fig.add_trace(
                go.Scatter(
                    x=plot_df.loc[future_plot_idx, "CREATEDDATE"],
                    y=plot_df.loc[future_plot_idx, "Prediction"],
                    mode="lines+markers",
                    name="Extended Forecast (Future)",
                    line=dict(color="#2ca02c", width=3),
                    marker=dict(size=4),
                    hovertemplate="<b>Future Projection</b><br>Date: %{x|%Y-%m-%d}<br>Forecast: ₹%{y:,.2f}<extra></extra>"
                )
            )

            # Vertical boundary line demarcating actuals from future
            fig.add_vline(
                x=max_actual_date.timestamp() * 1000, # ms timestamp for Plotly
                line_width=2,
                line_dash="dot",
                line_color="#d62728",
                annotation_text="Actuals Boundary (Forecast Extends Beyond)",
                annotation_position="top left",
                annotation_font=dict(color="#d62728", size=12)
            )

        fig.update_layout(
            title=f"Revenue Trajectory: Historical Actuals & Extended 50-Year Forecast ({forecast_type} View)",
            xaxis_title="Timeline",
            yaxis_title="Revenue Amount (₹)",
            hovermode="x unified",
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
            template="plotly_white",
            height=620
        )

        # Enable range slider and quick zoom buttons
        fig.update_xaxes(
            rangeslider_visible=True,
            rangeselector=dict(
                buttons=list([
                    dict(count=1, label="1Y", step="year", stepmode="backward"),
                    dict(count=5, label="5Y", step="year", stepmode="backward"),
                    dict(count=10, label="10Y", step="year", stepmode="backward"),
                    dict(count=25, label="25Y", step="year", stepmode="backward"),
                    dict(count=50, label="50Y", step="year", stepmode="backward"),
                    dict(step="all", label="All")
                ])
            )
        )

        st.plotly_chart(fig, use_container_width=True)
    else:
        st.warning("No data found within the selected date range.")

with tab2:
    if not plot_df.empty:
        st.subheader(f"{forecast_type} Revenue Projection Table")

        output_df = plot_df.copy()
        output_df["Period Type"] = output_df["CREATEDDATE"].apply(
            lambda d: "Historical Actual" if d <= max_actual_date else "Future Projection"
        )
        output_df["Actual Amount"] = output_df["TOTALAMOUNT"].apply(
            lambda v: f"{v:,.2f}" if pd.notna(v) else "N/A (Future Projection)"
        )
        output_df["Predicted Amount"] = output_df["Prediction"].map('{:,.2f}'.format)
        output_df["Variance / Difference"] = (output_df["TOTALAMOUNT"] - output_df["Prediction"]).apply(
            lambda v: f"{v:,.2f}" if pd.notna(v) else "N/A"
        )

        display_df = output_df[[
            "CREATEDDATE", "Period Type", "Actual Amount", "Predicted Amount", "Variance / Difference"
        ]].rename(columns={"CREATEDDATE": f"{forecast_type} End Date"})

        st.dataframe(display_df, use_container_width=True)

        # Download forecast CSV
        csv_data = display_df.to_csv(index=False)
        st.download_button(
            label="📥 Download Extended Forecast CSV",
            data=csv_data,
            file_name=f"revenue_forecast_{forecast_type.lower()}_50_years.csv",
            mime="text/csv"
        )
    else:
        st.warning("No data found within the selected date range.")
