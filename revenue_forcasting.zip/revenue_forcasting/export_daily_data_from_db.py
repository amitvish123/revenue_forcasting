import oracledb
import pandas as pd
import os
# Oracle connection
# connection = oracledb.connect(
#     user="YOUR_USERNAME",
#     password="YOUR_PASSWORD",
#     dsn="HOST:PORT/SERVICE_NAME"
# )
dsn = f"172.18.210.27:1521/IFMIS"
connection = oracledb.connect(
    user="system",
    password="system",
    dsn=dsn
)

major_head_list = pd.read_csv("major_head_list.csv")
revenue_dir_path = "/data/amit/revenue_forcasting/revenue_data"
os.makedirs(revenue_dir_path, exist_ok=False)
for major_head in major_head_list["MAJOR_HEAD"]: 
    query = f"""
    SELECT
        TRUNC(TXN_DATE) AS TXN_DATE,
        SUM(NVL(NET_AMOUNT, 0)) AS TOTAL_REVENUE
    FROM PROD_IFMIS.FD_RND_CMN_RCPT_TXN
    WHERE TXN_DATE IS NOT NULL AND MAJOR_HEAD = '{major_head}'
    GROUP BY TRUNC(TXN_DATE)
    ORDER BY TRUNC(TXN_DATE)
    """

    # query = "select DISTINCT CHALLAN_TYPE FROM PROD_IFMIS.FD_RND_CMN_RCPT_TXN"
    df = pd.read_sql(query, connection)



    # df.to_csv("Challan_Type_list.csv", index=False)
    # Ensure datetime
    df["TXN_DATE"] = pd.to_datetime(df["TXN_DATE"])

    # Save CSV
    df.to_csv(f"daily_mh_{major_head}_revenue.csv", index=False)

    print(df.head())
    print(f"\nTotal days: {len(df)}")
    print(f"Saved as daily_mh_{major_head}_revenue.csv")

connection.close()